<?php
    include "connection.php";
	include "nav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="15">
    <title>Vehicle Verification</title>
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="verify.css">
</head>
<body>
	<?php
        if(isset($_SESSION['login_user']))
        {
            ?>
				<section>
					<div class="container">
							<div>
								<a style="color:white;margin-right:25px; float:right; width:60px; background:blue; padding:5px; border:2px solid grey; border-radius:15px; text-align:center;" href="head.php">Back</a>
							</div>
						
						
						<br><br>
						<div class="title">Vehicle Full Verification</div>
						<br>
						
							<div class="user_details">				
								<?php  
									$result=mysqli_query($connect,"SELECT * from `vehiclefull` where `status`='Pending';");     
									
									echo "<div  class='scroll'>";
									echo "<table class ='table'>";
									echo "<tr style='background-color: lightgreen;'>";

									echo "<th>"; echo "Entry ID"; echo "</th>"; 
									echo "<th>"; echo "Customer Name"; echo "</th>";
									echo "<th>"; echo "Place From"; echo "</th>";   
									echo "<th>"; echo "Transport Name"; echo "</th>";
									echo "<th>"; echo "Vehicle Number"; echo "</th>";
									echo "<th>"; echo "Vehicle Type"; echo "</th>";
									echo "<th>"; echo "Entry Gate Number"; echo "</th>";
									echo "<th>"; echo "Allow"; echo "</th>";

									echo "</tr>";
									while($row=mysqli_fetch_assoc($result)){
										echo "<tr style='background-color: white;'>";
										?> <form action="verifyvehiclefull.php" method="post"> <?php
										echo "<td>"; echo $row['ID']; echo "</td>";
										echo "<td>"; echo $row['customer_name']; echo "</td>";
										echo "<td>"; echo $row['place_from']; echo "</td>";
										echo "<td>"; echo $row['transport_name']; echo "</td>";
										echo "<td>"; echo $row['vehicle_no']; echo "</td>";
										echo "<td>"; echo $row['vehicle_type']; echo "</td>";
										echo "<td>"; echo $row['entry_gate_no']; echo "</td>";
										echo "<td>"; 
											?> 
												<div class="btn">
													<div class="button">
														<input type="hidden" name="vehiclesubmit" value="<?php echo $row['vehicle_no'];?>"> 
														<input type="submit" name="verify" value="Verify">                                        
													</div>
												</div> 
											<?php   
										echo "</td>";
										?>
										</form>
										<?php
										echo "</tr>";
									}
									echo "</table>";
									echo "</div>";

									?>

								
							</div>
						
					</div>
				</section>
            <?php
        }
        else
        { 
			?>
                <script>
                    window.location="../index.php";
                </script> 
            <?php
        }
    ?>
	
	
</body>
</html>
