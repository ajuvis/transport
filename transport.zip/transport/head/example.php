<?php 
    include "connection.php";
    include "nav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>All Details</title>
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
        <link rel="stylesheet" href="details.css">
    </head>
    <body>
    
    <?php
        if(isset($_SESSION['login_user']))
        {
            ?>
                <div class="center">
                        <section>       
                                <div style="color:red;  font-family:cursive; margin-left:20px; margin-top:30px; font-wieght:bold; text-transform:uppercase; font-size:25px;">
                                        <?php
                                                if(isset($_SESSION['login_user']))
                                                {
                                                    $result=mysqli_query($connect,"SELECT * from head WHERE headID='$_SESSION[login_user]';");
                                                    $row=mysqli_fetch_assoc($result);
                                                    
                                                    echo "Welcome : ".$row['Full_Name'];                          
                                                }                                            
                                        ?>
                                       
                                          
                                        
                                        
                                </div>        
                        </section>
                        
                      
                            <div class="back">
                                <a style="color:black; float:right; padding:7px 15px 7px 15px; width:80px;  background:lightblue; border:3px solid grey; margin-right:30px; margin-bottom:0px; border-radius:25px; text-align:center;" href="head.php">Back</a>
                            </div>
                            <h1>Full Vehicle Details</h1> 
                            <form action="" method="post">
                                <input type="text" name="customer" id="" placeholder="Search by Customer Name" autocomplete="off">
                                <button type="submit" name="search">Search</button>
                            </form>
                            
                    <?php 
                        $res=mysqli_query($connect,"SELECT * FROM `final` WHERE `vehicle_is`='Full';");

                        echo "<table class ='table table-bordered table-hover'>";
                        echo "<tr style='background-color: rgba(32, 187, 156, 1); font-size: 20px; padding:3px;'>";

                        echo "<th>"; echo "PDF"; echo "</th>";
                        echo "<th>"; echo "Customer Name"; echo "</th>";
                        echo "<th>"; echo "Challan Number"; echo "</th>";
                        echo "<th>"; echo "Place from Coming"; echo "</th>";
                        echo "<th>"; echo "Remark"; echo "</th>";
                        echo "<th>"; echo "Transport Name"; echo "</th>";
                        echo "<th>"; echo "Vehicle Type"; echo "</th>";
                        echo "<th>"; echo "Vehicle Number"; echo "</th>";
                        echo "<th>"; echo "Entry Date"; echo "</th>";
                        echo "<th>"; echo "Entry Time"; echo "</th>";
                        echo "<th>"; echo "Exit Date and Time"; echo "</th>";
                        echo "<th>"; echo "Weight of Product on Challan"; echo "</th>";
                        echo "<th>"; echo "Vehicle Weight before Unloading"; echo "</th>";
                        echo "<th>"; echo "Vehicle Weight after Unloading"; echo "</th>";
                        echo "<th>"; echo "Driver Name"; echo "</th>";
                        echo "<th>"; echo "Driver Mobile Number"; echo "</th>";
                        echo "<th>"; echo "Challan Photo"; echo "</th>";
                        echo "<th>"; echo "Driver Photo"; echo "</th>";
                        echo "<th>"; echo "Driver ID Proof"; echo "</th>";
                        echo "<th>"; echo "Driver Sign"; echo "</th>";
                        echo "<th>"; echo "Entry Gate"; echo "</th>";
                        echo "<th>"; echo "Exit Gate"; echo "</th>";
                        

                        echo "</tr>";

                        while($row=mysqli_fetch_assoc($res))
                        {
                            ?><form action="downloadfull.php" method="post"><?php
                            
                            $challanphoto="<img class='img-circle profile_img' height=80 width=80 src='../staff/vehiclefull/".$row['challan_photo']."'>";
                            $driverphoto="<img class='img-circle profile_img' height=80 width=80 src='../staff/vehiclefull/".$row['driver_photo']."'>";
                            $driveridproof="<img class='img-circle profile_img' height=80 width=80 src='../staff/vehiclefull/".$row['driver_proof']."'>";
                            $driversign="<img class='img-circle profile_img' height=80 width=80 src='../staff/vehiclefull/".$row['driver_sign']."'>";
                            
                            echo "<tr style='background-color: lightgreen;'>";

                            echo "<td>"; 
								?> 
									<div class="btn">
										<div class="button">
											<input type="hidden" name="download" value="<?php echo $row['pdf_file'];?>"> 
											<input type="submit" name="downloadit" value="<?php echo $row['pdf_file'];?>">                                        
										</div>
									</div> 
								<?php   
							echo "</td>";
                            echo "<td>"; echo $row['customer_name']; echo "</td>";
                            echo "<td>"; echo $row['challan_no']; echo "</td>";
                            echo "<td>"; echo $row['place_from']; echo "</td>";
                            echo "<td>"; echo $row['remark']; echo "</td>";
                            echo "<td>"; echo $row['transport_name']; echo "</td>";
                            echo "<td>"; echo $row['vehicle_type']; echo "</td>";
                            echo "<td>"; echo $row['vehicle_no']; echo "</td>";
                            echo "<td>"; echo $row['entry_date']; echo "</td>";    
                            echo "<td>"; echo $row['entry_time']; echo "</td>";               
                            echo "<td>"; echo $row['exit_time']; echo "</td>";
                            echo "<td>"; echo $row['weight']; echo "</td>";
                            echo "<td>"; echo $row['weight_in']; echo "</td>";
                            echo "<td>"; echo $row['weight_out']; echo "</td>";
                            echo "<td>"; echo $row['driver_name']; echo "</td>";
                            echo "<td>"; echo $row['driver_mobile']; echo "</td>";
                            echo "<td>"; echo $challanphoto; echo "</td>";
                            echo "<td>"; echo $driverphoto; echo "</td>";
                            echo "<td>"; echo $driveridproof; echo "</td>";
                            echo "<td>"; echo $driversign; echo "</td>";
                            echo "<td>"; echo $row['entry_gate_no']; echo "</td>";                   
                            echo "<td>"; echo $row['exit_gate_no']; echo "</td>";
                            echo "</tr>";

                            echo "</table>";
                            ?></form><?php
                        }
                    ?>
                    
                </div>
            <?php
        }
        else
        { 
			?>
                <script>
                    window.location="../index.php";
                </script> 
            <?php
        }
    ?>
        
</body>
</html>
