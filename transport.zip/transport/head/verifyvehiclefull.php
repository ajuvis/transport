<?php
    include "connection.php";
    include "nav.php";

    if(isset($_POST['verify']))
		{
                $yes= $_POST['vehiclesubmit'];
                mysqli_query($connect,"UPDATE `vehiclefull` SET `status`='OK' WHERE vehicle_no='$yes';");
                ?>
                    <script>
                        var stri="<?php echo $yes; ?>";
                        alert("Vehicle Number: "+stri);
                        window.location="verifyfull.php";
                    </script>
                <?php
		}
?>