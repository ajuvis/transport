<?php
    include "connection.php";
    require('fpdf/fpdf.php');

    if(isset($_POST['downloadit']))
		{
                        $yes= $_POST['download'];
                        $result=mysqli_query($connect,"SELECT * FROM `final` WHERE `pdf_file`='$yes';");
                        $_row=mysqli_fetch_assoc($result);
       
                        $pdf = new FPDF('P','mm','A4');
                        $pdf->AddPage();

      
                        $pdf->SetTextColor('0','120','200');
                        $pdf->SetFont('Times','B',16);
                        $pdf->Cell(190	,10," [".$_row['pdf_file']."]",0,1,'C');

                        

                        $pdf->Cell(0,10,'',0,1);
                        $pdf->Cell(190,.1,'',1,1);
                        $pdf->Cell(0,7,'',0,1);

                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(50,15,'    Customer Name  :',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','B',13);
                        $pdf->Cell(0	,15,"".$_row['customer_name'],0,1);


                        $pdf->Cell(0,5,'',0,1);
                        $pdf->Cell(190,.1,'',1,1);
                        $pdf->Cell(0,5,'',0,1);

                       
                        
                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(57,15,'    Entry Gate Number :',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','',13);
                        $pdf->Cell(38,15,"".$_row['entry_gate_no'],0,0);

                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(57,15,' Exit Gate Number :',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','',13);
                        $pdf->Cell(38,15,"".$_row['exit_gate_no'],0,1);

                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(64,13,'    Entry Date and Time  :-',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','',13);
                        $pdf->Cell(56,13,"".$_row['entry_time'],0,1);

                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(64,13,'    Exit Date and Time    :-',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','',13);
                        $pdf->Cell(56,13,"".$_row['exit_time'],0,1);


                        $pdf->Cell(0,5,'',0,1);
                        $pdf->Cell(190,.1,'',1,1);
                        $pdf->Cell(0,5,'',0,1);


                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(50,15,'    Transport Name  :',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','',13);
                        $pdf->Cell(0,15,"".$_row['transport_name'],0,1);

                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(50,15,'    Vehicle Type       :',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','',13);
                        $pdf->Cell(45,15,"".$_row['vehicle_type'],0,0);

                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(45,15,'Vehicle Number :',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','B',13);
                        $pdf->Cell(50,15,"".$_row['vehicle_no'],0,1);

                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(50,15,'    Driver Name        :',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','',13);
                        $pdf->Cell(0,15,"".$_row['driver_name'],0,1);

                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(65,15,'    Driver Mobile Number  :',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','',13);
                        $pdf->Cell(0,15,"".$_row['transport_name'],0,1);


                        $pdf->Cell(0,5,'',0,1);
                        $pdf->Cell(190,.1,'',1,1);
                        $pdf->Cell(0,5,'',0,1);


                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(85,15,'    Weight of Product on Challan  :',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','B',13);
                        $pdf->Cell(0,15,"".$_row['weight'],0,1);

                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(69,15,'    Weight Before Unloading :',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','',13);
                        $pdf->Cell(26,15,"".$_row['weight_in'],0,0);

                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(64,15,'Weight Before Unloading :',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','',13);
                        $pdf->Cell(31,15,"".$_row['weight_out'],0,1);


                        $pdf->Cell(0,5,'',0,1);
                        $pdf->Cell(190,.1,'',1,1);
                        $pdf->Cell(0,5,'',0,1);


                        $pdf->SetTextColor('254','80','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(43,15,'    Status           :',0,0);
                        
                        $pdf->SetTextColor('0','0','0');
                        $pdf->SetFont('Courier','B',13);
                        $pdf->Cell(0,15,"".$_row['status'],0,1);


                        $pdf->Cell(0,5,'',0,1);
                        $pdf->Cell(190,.1,'',1,1);
                        $pdf->Cell(0,5,'',0,1);

                        $pdf->AddPage();

                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(95,10,'    Driver Photo   :',0,0);

                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(95,10,'    Driver Photo   :',0,1);

                        $pdf->Image('../staff/vehicleempty/'.$_row['driver_photo'],25,27,60,75);
                       
                        $pdf->Image('../staff/vehicleempty/'.$_row['driver_sign'],125,27,60,50);

                        $pdf->Cell(0,110,'',0,1);

                        $pdf->SetTextColor('80','120','0');
                        $pdf->SetFont('Arial','B',14);
                        $pdf->Cell(0,10,'    Driver Proof   :',0,1);

                        $pdf->Image('../staff/vehicleempty/'.$_row['driver_proof'],35,150,120,95);

                        $pdf->Output($_row['customer_name'].'.pdf','I');
		}
?>