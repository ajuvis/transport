<?php
    include "connection.php";
    include "nav.php";

    if(isset($_POST['exit']))
		{
                $yes= $_POST['vehicleexit'];
                mysqli_query($connect,"UPDATE `overall` SET `status`='Weight Verified from Head', `exit_allow`='Allow', `remark`='$_POST[remark]' WHERE vehicle_no='$yes';");
                ?>
                    <script>
                        var stri="<?php echo $yes; ?>";
                        alert("Vehicle Number: "+stri);
                        window.location="exitempty.php";
                    </script>
                <?php
		}
?>