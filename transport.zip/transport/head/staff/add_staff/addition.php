<?php
     include "../../../connection/connection.php";
    /*include "nav.php"; */
             
        if(isset($_POST['submit']))
        {
            $pre_stmt = $connect->prepare("SELECT * from staff_details WHERE s_username = ?");
			$pre_stmt->bind_param("s",$_POST["s_username"]);
			$pre_stmt->execute();
			$result = $pre_stmt->get_result();
			if($result->num_rows > 0){
                $pre_stmt->close();
                $connect->close();
				?>
                    <script>
                        alert("Username is already exist!");
                        window.location="add_staff.php";
                    </script>
                <?php
			}
            else{
                $password = password_hash($_POST['s_password'], PASSWORD_BCRYPT,['cost'=> 9] );

                $pre_stmtinsert = $connect->prepare("INSERT INTO staff_details(s_username,full_name,mobile_no,address,blood_group,location,s_password) VALUES (?,?,?,?,?,?,?)");
                $pre_stmtinsert->bind_param("sssssss",$_POST['s_username'],$_POST['name'],$_POST['mobile'],$_POST['address'],$_POST['blood'],$_POST['assign'],$password);
                $pre_stmtinsert->execute();
                if($pre_stmtinsert){
                    $pre_stmt->close();
                    $connect->close();
                    ?>
                        <script>
                            alert("Added Successfully!");
                            window.location="add_staff.php";
                        </script>
                    <?php
                } 
            }					
                       /*  move_uploaded_file($_FILES['file']['tmp_name'],"image/".$_FILES['file']['name']);
                        $pic=$_FILES['file']['name'];
                        move_uploaded_file($_FILES['file1']['tmp_name'],"image/".$_FILES['file1']['name']);
                        $pic1=$_FILES['file1']['name'];
                        move_uploaded_file($_FILES['file2']['tmp_name'],"image/".$_FILES['file2']['name']);
                        $pic2=$_FILES['file2']['name']; 
                        
						$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                        mysqli_query($connect,"INSERT INTO `staff` VALUES ('$_POST[id]','$_POST[name]','$password','$_POST[mobile]','$_POST[address]','$_POST[birth]','$_POST[joining]','$_POST[blood]','$_POST[assign]','$_POST[addharno]','$pic1','$pic','$pic2');");
                            ?>
                                <script>
                                   alert("Staff Details Added Successfully");
                                   window.location="staff_add.php";
                                </script>
                             <?php
                        */                                       
                }
    
                          
        ?>	