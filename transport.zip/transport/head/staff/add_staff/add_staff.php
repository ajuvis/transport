<?php
	include "../../../connection/after_login_connection.php";
	include "../../header/s_nav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Staff</title>  
	<!-- CSS only -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
   <!-- JavaScript Bundle with Popper -->
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
   <script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<link rel="stylesheet" href="../../../css/head/staff/staff_addition.css">
</head>
<body>

	<?php
        if(isset($_SESSION['login_user']))
        {
            ?>
				<div class="center">
					<div class="container">
					
					<div style="color:orange; font-family:cursive; float:right;  font-wieght:bold; text-transform:uppercase; margin-bottom:10px; font-size:15px;">
						<?php
								if(isset($_SESSION['login_user']))
								{
									$result=mysqli_query($connect,"SELECT * from head WHERE headID='$_SESSION[login_user]';");
									$row=mysqli_fetch_assoc($result);
									
									echo "Welcome : ".$row['Full_Name'];                          
								}                                            
						?>
					</div>
					<div class="back">
						<a href="../../dashboard.php">Back</a>
					</div>

					<script>
						function myfun(){			
							var c= document.getElementById("password").value;
							var b= document.getElementById("password1").value;
							if(c!=b){
								document.getElementById("messages1").innerHTML="*Password does not match.";
								return false;
							} 
						}
					</script>  
					
						<div class="title">Add Staff</div>
						

						<form onsubmit="return myfun()" action="addition.php"  method="post" enctype="multipart/form-data">
							<div class="user_details">				
								<div class="input-box">
									<span class="details">Username</span>
									<input type="text" name="s_username" placeholder="Enter Username" required>
								</div>										

								<div class="input-box">
									<span class="details">Full Name</span>
									<input type="text" name="name" placeholder="Enter Full Name" required>
								</div>
								
								<div class="input-box">
									<span class="details">Mobile No.</span>
									<input type="text" name="mobile" pattern="[6-9]{1}[0-9]{9}" 
       								title="Invalid input" placeholder="Enter Mobile" required>
								</div>

								<div class="input-box">
									<span class="details">Address</span>
									<input type="text" name="address" placeholder="Enter Address" required>
								</div><!-- 
								
								<div class="input-box">
									<span class="details">Date of Birth</span>
									<input type="date" name="birth" placeholder="" required>
								</div>
								
								<div class="input-box">
									<span class="details">Date of Joining</span>
									<input type="date" name="joining" placeholder="" required>
								</div> -->
								
								<div class="input-box">
									<span class="details">Blood Group</span>
									<input type="text" name="blood" placeholder="Enter Blood Group" required>
								</div>
								
								<div class="input-box">
									<span class="details">Assign Place</span>
									<select name="assign" id="" required>
										<option value="Gate Entry">Gate Entry</option>
										<option value="Weighting Area">Weighting Place</option>
									</select>
								
								</div>

								<!-- <div class="input-box">
									<span class="details">Addhar Card Number</span>
									<input type="text" name="addharno" placeholder="Enter Aadhar Card Number" required>
								</div>
								
								<div class="input-box">
									<span class="details">Addhar Card Photo</span>
									<input type="file" name="file1" accept="image/*" placeholder="" required>
								</div>

								<div class="input-box">
									<span class="details">Photo</span>
									<input type="file" name="file" accept="image/*" placeholder="" required>
								</div>

								<div class="input-box">
									<span class="details">Sign.</span>
									<input type="file" name="file2" accept="image/*" placeholder="" required>
								</div> -->

								<div class="input-box">
									<span class="details">Password</span>
									<input type="password" name="s_password" id="password" placeholder="Enter Password" required>
								</div>

								<div class="input-box">
									<span class="details">Re-enter Password</span>
									<input type="password" name="password1" id="password1" placeholder="Re-enter Password" required>
									<div style="color:red; font-size:25px;"><span1 id="messages1"></span1></div>
								</div>

								<div class="btn">
									<div class="button">
										<input type="submit" id="submit" name="submit" value="Submit">
									</div>
									<div class="reset">
										<input type="reset" value="Reset">
									</div>		
								</div>
								
								
							</div>
						</form>
					</div>
				</div>
            <?php
        }
        else
        { 
			?>
                <script>
                    window.location="../index.php";
                </script> 
            <?php
        }
    ?> 
</body>
</html> 