<?php
    include "../../../connection/after_login_connection.php";
    $id = $_GET['id']; 

    if(isset($_POST['update'])){
        $pre_stmt = $connect->prepare("UPDATE staff_details SET s_username = ? , full_name = ? , mobile_no = ? , address = ? , blood_group = ? , location = ? WHERE id = ? ");
		$pre_stmt->bind_param("sssssss",$_POST["username"],$_POST["full_name"],$_POST["mobile_no"],$_POST["address"],$_POST["blood_group"],$_POST["location"],$id);
		$pre_stmt->execute();
	    header('location: ../staff_details/staff_details.php?u=1');
		
    }

?>