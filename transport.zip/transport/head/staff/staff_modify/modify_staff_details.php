<?php
    include "../../../connection/after_login_connection.php";
	include "../../header/s_nav.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="../../../css/head/staff/staff_modifys.css">  
</head>
<body>
    <?php
        if(isset($_SESSION['login_user']))
        {
            $id = $_GET['id']; 

            $pre_stmt = $connect->prepare("SELECT * from staff_details WHERE id = ? ");
			$pre_stmt->bind_param("s",$id);
			$pre_stmt->execute();
			$result = $pre_stmt->get_result();
            $row = $result->fetch_assoc();

            ?>
                <div class="center">
                    <div class="container">
                    <div class="container1" >
                        <div class="back">
                            <a href="../staff_details/staff_details.php">Back</a>
                        </div>
                        <div class="edit">
                            <!-- <img src="../../image/delete.png"> -->
                            <i class="fas fa-edit"></i>
                            <h2>Edit Staff Record</h2><br>
                            <form action="update.php?id=<?php echo $id; ?>" method="post">
                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="id" class="col-form-label">Id</label>
                                    </div> 
                                    <div class="col-sm-9">
                                    <input type="text" id="id" class="form-control" value="<?php echo $row['id']; ?>"  name="id" placeholder="Id" disabled required>    
                                    </div>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="username" class="col-form-label">Username</label>
                                    </div> 
                                    <div class="col-sm-9">
                                    <input type="text" id="username" class="form-control" value="<?php echo $row['s_username']; ?>" name="username" placeholder="Username" required>    
                                    </div>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="full_name" class="col-form-label">Full Name</label>
                                    </div> 
                                    <div class="col-sm-9">
                                    <input type="text" id="full_name" class="form-control" value="<?php echo $row['full_name']; ?>"  name="full_name" placeholder="Full Name" required>    
                                    </div>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="mobile_no" class="col-form-label">Mobile No</label>
                                    </div> 
                                    <div class="col-sm-9">
                                    <input type="text" id="mobile_no" class="form-control" value="<?php echo $row['mobile_no']; ?>"  name="mobile_no" placeholder="Mobile No" required>    
                                    </div>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="address" class="col-form-label">Address</label>
                                    </div> 
                                    <div class="col-sm-9">
                                    <input type="text" id="address" class="form-control" value="<?php echo $row['address']; ?>"  name="address" placeholder="Address" required>    
                                    </div>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="blood_group" class="col-form-label">Blood Group</label>
                                    </div> 
                                    <div class="col-sm-9">
                                    <input type="text" id="blood_group" class="form-control" value="<?php echo $row['blood_group']; ?>"  name="blood_group" placeholder="Blood Group" required>    
                                    </div>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="location" class="col-form-label">Location</label>
                                    </div> 
                                    <div class="col-sm-9">
                                        <?php
                                            if($row['location']==="Gate Entry"){
                                                ?>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="location" value="Gate Entry" id="Gate_Entry" checked>
                                                        <label class="form-check-label" for="Gate_Entry">
                                                            Gate Entry
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="location" value="Weighting Place" id="Weighting_Place">
                                                        <label class="form-check-label" for="Weighting_Place">
                                                            Weighting Place
                                                        </label>
                                                    </div>  
                                                <?php
                                            }
                                            else{
                                                ?>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="location" value="Gate Entry" id="Gate_Entry" >
                                                        <label class="form-check-label" for="Gate_Entry">
                                                            Gate Entry
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="location" value="Weighting Place" id="Weighting_Place" checked>
                                                        <label class="form-check-label" for="Weighting_Place">
                                                            Weighting Place
                                                        </label>
                                                    </div>  
                                                <?php
                                            }
                                        ?>

                                        </div>   
                                    </div>

                                </div>

                                <br>
                                <div class="form-group" style=" display:flex; justify-content: center;">
                                    <button type="submit" name="update"  class="btn btn-success">Update</button>
                                </div>
                               
                            </form>
                        </div>  
                    </div>
                    </div>
                    
                </div>
            <?php
        }
        else
        { 
			?>
                <script>
                    window.location="../index.php";
                </script> 
            <?php
        }
    ?>   
                      
    </body>
</html>