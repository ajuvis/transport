<?php
    
    $id = $_GET['id'];

    include "../../../connection/after_login_connection.php";                   
    $pre_stmt = $connect->prepare("DELETE FROM staff_details WHERE id = ? ");
	$pre_stmt->bind_param("s",$id);
	$pre_stmt->execute();
    header('location: ../staff_details/staff_details.php?m=1');
?>