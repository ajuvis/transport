<?php
	include "../../../connection/after_login_connection.php";
	include "../../header/s_nav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Gate</title>
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
        <!-- JavaScript Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
        <link rel="stylesheet" href="../../../css/head/staff/staff_info.css">
        
        
    </head>
    <body>

    <?php
        if(isset($_SESSION['login_user']))
        {
            ?>
                <div class="center">
                    <div class="container">
                    <table class ='table table-dark table-striped'>
                        
                        <section>       
                                <div style="color:orange; float:right; font-family:cursive; margin-right:20px;  font-wieght:bold; text-transform:uppercase; font-size:15px;">
                                        <?php
                                                if(isset($_SESSION['login_user']))
                                                {
                                                    $result=mysqli_query($connect,"SELECT * from head WHERE headID='$_SESSION[login_user]';");
                                                    $row=mysqli_fetch_assoc($result);
                                                    
                                                    echo "Welcome : ".$row['Full_Name'];                          
                                                }                                            
                                        ?>
                                </div>    
                                    
                                <div class="back">
                                    <a href="../../dashboard.php">Back</a>
                                </div>
                        </section>
                        
                        
                            
                            <div class="h">
                                Staff Details
                            </div>
                            
                        
                    <?php 
                        $res=mysqli_query($connect,"SELECT * FROM `staff_details`;");
                        echo "<tr style='background-color: rgba(32, 187, 156, 1); font-size: 20px; padding:3px;'>";

                        echo "<th>"; echo "ID"; echo "</th>";
                        echo "<th>"; echo "Username"; echo "</th>";
                        echo "<th>"; echo "Name"; echo "</th>";
                        echo "<th>"; echo "Allocate Place"; echo "</th>";
                        echo "<th>"; echo "Moblie"; echo "</th>";
                        echo "<th>"; echo "Address"; echo "</th>";/* 
                        echo "<th>"; echo "Date of Birth"; echo "</th>";
                        echo "<th>"; echo "Date of Joining"; echo "</th>"; */
                        echo "<th>"; echo "Blood Group"; echo "</th>";/* 
                        echo "<th>"; echo "Addhar Card No"; echo "</th>";
                        echo "<th>"; echo "Addhar Card Photo"; echo "</th>";
                        echo "<th>"; echo "Staff Photo"; echo "</th>";
                        echo "<th>"; echo "Sign"; echo "</th>"; */
                        echo "<th>"; echo "Action"; echo "</th>";

                        echo "</tr>";

                        while($row=mysqli_fetch_assoc($res))
                        {
                           /*  $staffphoto="<img class='img-circle profile_img' height=100 width=100 src='image/".$row['staffphoto']."'>";
                            $addharphoto="<img class='img-circle profile_img' height=100 width=100 src='image/".$row['addharphoto']."'>";
                            $sign="<img class='img-circle profile_img' height=100 width=100 src='image/".$row['sign']."'>"; */
                            echo "<tr style='background-color: lightgreen;'>";
                            $id=$row['id'];
                            echo "<td>"; echo $row['id']; echo "</td>";
                            echo "<td>"; echo $row['s_username']; echo "</td>";
                            echo "<td>"; echo $row['full_name']; echo "</td>";            
                            echo "<td>"; echo $row['location']; echo "</td>";  
                            echo "<td>"; echo $row['mobile_no']; echo "</td>";
                            echo "<td>"; echo $row['address']; echo "</td>";
                            /* echo "<td>"; echo $row['birth']; echo "</td>";
                            echo "<td>"; echo $row['joining']; echo "</td>"; */
                            echo "<td>"; echo $row['blood_group']; echo "</td>";                  
                            /* echo "<td>"; echo $row['addharno']; echo "</td>";
                            echo "<td>"; echo $addharphoto; echo "</td>";
                            echo "<td>"; echo $staffphoto; echo "</td>";
                            echo "<td>"; echo $sign; echo "</td>"; */
                            echo "<td>"; echo " <a style='color:white;' href='../staff_modify/delete.php?id=$id' class='del_record'> <i class='fas fa-trash-alt'></i></a> &nbsp; &nbsp; <a style='color:white;' href='../staff_modify/modify_staff_details.php?id=$id'> <i class='fas fa-edit'></i> </a>"; echo "</td>";
                            echo "</tr>";
                        }
                    ?>
    
                    </table>
                    </div>
                </div>
            <?php
            if(isset($_GET['m'])) : ?>
                <div class="flash-data" data-flashdata="<?= $_GET['m']; ?>"></div>
                
            <?php endif;
            if(isset($_GET['u'])) : ?>
                <div class="update-data" data-updatedata="<?= $_GET['u']; ?>"></div>
                
            <?php endif;
        }
        else
        { 
			?>
                <script>
                    window.location="../index.php";
                </script> 
            <?php
        }
    ?>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../js/jquery.min.js" ></script>
    <script>
        $('.del_record').on('click',function(e){
            e.preventDefault();
            const href = $(this).attr('href')

            Swal.fire({
            title: 'Are you sure?',
            text: "Record will be deleted?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Delete Record'
            }).then((result) => {
                if (result.isConfirmed) {
                    /* Swal.fire(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                    ) */
                    if(result.value){
                        document.location.href = href;
                    }
                }
            })
        })

        const flashdata = $('.flash-data').data('flashdata')
        if(flashdata){
            Swal.fire({    
                type: 'success',
                title: 'Success',
                text: 'Record has been deleted.'
            })
        }

        const updatedata = $('.update-data').data('updatedata')
        if(updatedata){
            Swal.fire(  
                'Updated!',
                'Record has been updated.',
                'success'
            )
        }


    </script>
        
</body>
</html>
