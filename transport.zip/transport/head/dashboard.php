<?php
	include "../connection/connection.php";
	include "header/d_nav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Head</title>
  <!--  <meta http-equiv="refresh" content="15"> -->
   <!-- CSS only -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
   <!-- JavaScript Bundle with Popper -->
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
   <script src="https://kit.fontawesome.com/a076d05399.js"></script>
   <link rel="stylesheet" href="../css/head/dashboard.css">
</head>
<body>

   <?php
        if(isset($_SESSION['login_user']))
        {
            
            ?>
               <div class="center">   
                  <div class="container">
                     <div style="color:orange; font-family:cursive;  font-wieght:bold; text-transform:uppercase; margin-bottom:10px; font-size:15px; text-align:center;">
                           <?php
     
                                 if(isset($_SESSION['login_user']))
                                 {
                                       $result=mysqli_query($connect,"SELECT * from head WHERE headID='$_SESSION[login_user]';");
                                       $row=mysqli_fetch_assoc($result);
                                    
                                       echo "WELCOME : ".$row['Full_Name'];                          
                                 }    
                                 $count1=0;
                                 $count2=0;
                                 $count3=0;
                                 $count4=0;
                                 $count5=0;
                                 $count6=0;
                               /*   $result1=mysqli_query($connect,"SELECT * from `vehiclefull` WHERE `status`='Pending';");
                                 $count=mysqli_num_rows($result1);
                                 $result2=mysqli_query($connect,"SELECT * from `overall` WHERE (`status`='Weight Verified from Staff' || `status`='Weight Verification is Pending') && `vehicle_is`='Full';");
                                 $count1=mysqli_num_rows($result2);
                                 $result3=mysqli_query($connect,"SELECT * from `final` WHERE `vehicle_is`='Full';");
                                 $count2=mysqli_num_rows($result3);
                                 $result4=mysqli_query($connect,"SELECT * from `vehicleempty` WHERE `status`='Pending';");
                                 $count3=mysqli_num_rows($result4);
                                 $result5=mysqli_query($connect,"SELECT * from `overall` WHERE (`status`='Weight Verified from Staff' || `status`='Weight Verification is Pending') && `vehicle_is`='Empty';");
                                 $count4=mysqli_num_rows($result5);
                                 $result6=mysqli_query($connect,"SELECT * from `final` WHERE `vehicle_is`='Empty'");
                                 $count5=mysqli_num_rows($result6); */
                           ?>
                     </div>

                     <!-- Row number 2 -->

                     <div class="card-group">
                        <div class="card">
                           <a href="verify_finished_goods.php">
                              <div class="noti">
                                 <div class="count1">
                                    <i class="fas fa-truck-pickup"></i>
                                    <?php
                                       echo $count1;
                                    ?>
                                 </div> 
                              </div>
                              <div class="card-body">
                                 <div class="title1">
                                    <h4 class="card-title">Verify Vehicle</h4>
                                    <h5 class="card-title">(It is an EMPTY vehicle)</h5>
                                 </div>
                                 <br>
                                 <p class="card-text">The data filling is done by staff members. Please verify it.</p>
                              </div>
                           </a>
                        </div>

                        <div class="card">
                           <a href="exit_finished_goods.php">
                              <div class="noti">
                                 <div class="count2">
                                    <?php
                                       echo $count2;
                                    ?>
                                    <i class="fas fa-truck-moving"></i>
                                 </div> 
                              </div>
                              <div class="card-body">
                                 <div class="title2">
                                    <h4 class="card-title">Exit</h4>
                                    <h5 class="card-title">(Loading is done of Finished Good)</h5>
                                 </div>
                                 <br>
                                 <p class="card-text">Staff members loaded the finished goods. Please allow for an exit.</p>
                              </div>
                           </a>
                        </div>

                        <div class="card">
                           <a href="details_finished_goods.php">
                              <div class="noti">
                                 <div class="count3">
                                    <?php
                                       echo $count3;
                                    ?>
                                    <i class="far fa-list-alt"></i>
                                 </div> 
                              </div>
                              <div class="card-body">
                                 <div class="title3">
                                    <h4 class="card-title">Details</h4>
                                    <h5 class="card-title">(Finished Goods)</h5>
                                 </div>
                                 <br>
                                 <p class="card-text">An empty vehicle with Finished Goods loaded gets in the market.</p>
                              </div>
                           </a>
                        </div>
                     </div>

                     <!-- Row number 2 -->

                     <div class="card-group">
                        <div class="card">
                           <a href="verify_raw_materials.php">
                              <div class="noti">
                                 <div class="count1">
                                    <i class="fas fa-truck-moving"></i>
                                    <?php
                                       echo $count4;
                                    ?>
                                 </div> 
                              </div>
                              <div class="card-body">
                                 <div class="title1">
                                    <h4 class="card-title">Verify Vehicle</h4>
                                    <h5 class="card-title">(It contains Raw Material.)</h5>
                                 </div>
                                 <br>
                                 <p class="card-text">The data filling is done by staff members. Please verify it.</p>
                              </div>
                           </a>
                        </div>

                        <div class="card">
                           <a href="exit_raw_materials.php">
                              <div class="noti">
                                 <div class="count2">
                                    <?php
                                       echo $count5;
                                    ?>
                                    <i class="fas fa-truck-pickup"></i>
                                 </div> 
                              </div>
                              <div class="card-body">
                                 <div class="title2">
                                    <h4 class="card-title">Exit</h4>
                                    <h5 class="card-title">(Unloading is done of Raw Material)</h5>
                                 </div>
                                 <br>
                                 <p class="card-text">Staff members unloaded the raw material. Please allow for an exit.</p>
                              </div>
                           </a>
                        </div>

                        <div class="card">
                           <a href="details_raw_materials.php">
                              <div class="noti">
                                 <div class="count3">
                                    <?php
                                       echo $count6;
                                    ?>
                                    <i class="far fa-list-alt"></i>
                                 </div> 
                              </div>
                              <div class="card-body">
                                 <div class="title3">
                                    <h4 class="card-title">Details</h4>
                                    <h5 class="card-title">(Raw Materials)</h5>
                                 </div>
                                 <br>
                                 <p class="card-text">The list of unloaded vehicles.</p>
                              </div>
                           </a>
                        </div>
                     </div>

                     <!-- Row number 3 -->

                     <div class="card-group">
                        <div class="card">
                           <a href="staff/add_staff/add_staff.php">
                              <div class="noti">
                                 <div class="count4">
                                    <i class="fas fa-user-plus"></i>
                                 </div> 
                              </div>
                              <div class="card-body">
                                 <div class="title4">
                                    <h4 class="card-title">Add</h4>
                                 </div>
                                 <br>
                                 <p class="card-text">Add the details of new staff and create password.</p>
                              </div>
                           </a>
                        </div>

                      <!--   <div class="card">
                           <a href="staff/staff_modify/modify_staff_details.php">
                              <div class="noti">
                                 <div class="count2">
                                    <i class="fas fa-user-edit"></i>
                                 </div> 
                              </div>
                              <div class="card-body">
                                 <div class="title2">
                                    <h4 class="card-title">Modify / Delete</h4>
                                 </div>
                                 <br>
                                 <p class="card-text">Modify or Delete the record of staff members.</p>
                              </div>
                           </a>
                        </div> -->

                        <div class="card">
                           <a href="staff/staff_details/staff_details.php">
                              <div class="noti">
                                 <div class="count3">
                                    <i class="fas fa-list-alt"></i>
                                 </div> 
                              </div>
                              <div class="card-body">
                                 <div class="title3">
                                    <h4 class="card-title">List of Staff</h4>
                                 </div>
                                 <br>
                                 <p class="card-text">The list of Staff and take the overview of records.</p>
                              </div>
                           </a>
                        </div>
                     </div>
                        
                  </div>   
               </div>
            <?php
         }
         else
         { 
			   ?>
               <script>
                  window.location="../index.php";
               </script> 
            <?php
         }
      ?>     	
</body>
</html>