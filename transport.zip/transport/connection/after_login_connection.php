<?php
    session_start();
    $connect=mysqli_connect("localhost","root","","transport");  /* server name, username, password , database name */

    if($connect->connect_error){
        $connect->connect_error;
    }
?>