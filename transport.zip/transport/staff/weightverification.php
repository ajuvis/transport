<?php
    include "connection.php";
	include "nav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weight Verification</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
    
	<style>
		/********* Main Section **********/

		section{
			display: flex;
			width: 100%;
			justify-content: center;
			align-items: center;
			padding-top: 40px;
		}

		.container{
			max-width: 1300px;
			width: 100%;
			background: white;
			padding: 25px 80px;
			border-radius: 3px;
			margin-bottom: 50px;
		}


		.container .title{
			
			font-size: 35px;
			font-weight: 700;
			text-align: center;
			padding: 10px;
			border-bottom: 2px solid black;
		}

		.container .title::before{
			content: '';
			position: absolute;
			left: 0;
			bottom: 0;
			height: 5px;
			width: 30px;	
		}

		.container .staffid{
			margin-top: 20px;
			font-size: 20px;
			font-weight: 500;

		}
		.container .staffname{
			margin-top: 10px;
			margin-bottom: 50px;
			font-size: 20px;
			font-weight: 500;

		}
		.scroll{
            width:100%;
            background: red;
            margin-bottom:10px;
        }
        .scroll .table{
            width:100%;
        }
        .scroll .table tr th{
            text-align:center;
            font-size: 22px;
			height:50px;
        }
        .scroll .table tr td{
            text-align:center;
            font-size: 18px;
            height:50px;
        }
		
		.container form .user_details 
		{
			text-align:center;
			margin: auto; 
		}

		.container form .user_details .btn 
		{
			display:inline-block;
			margin: auto; 
		}

		.container form .user_details .btn .button{
			padding:50px;
		}

		.container form .user_details .btn .button input{	
			height: 33px;
			width: 150px;
			font-size: 20px;
			font-weight: 600;
			border-radius: 15px;
			background-color: lightblue;
			color: black;
			cursor:pointer;
		}

		.container form .btn .button input:hover{
			background-color: green;
            color:white;
		}


       

		@media (max-width: 720px){
			.container{
				max-width: 100%;
			}
			form .user_details .input-box{
				margin-bottom: 15px;
				width: 100%;
			}
			.container form .user_details{
				max-height: 500px;
				overflow-y: scroll;
			}
			
		}
	</style>
</head>
<body>

	<?php
		if(isset($_SESSION['login_user2'])){
			?>
				<section>
					<div class="container">

							<div>
								<a style="color:white;margin-right:25px; float:right; width:60px; background:blue; padding:5px; border:2px solid grey; border-radius:15px; text-align:center;" href="weightout.php">Back</a>
							</div>
						
						
						<br><br><br>
						<div class="title">Weight Verification</div>
						<div class="staffid">
							<?php
									if(isset($_SESSION['login_user2']))
									{
										$result=mysqli_query($connect,"SELECT * from staff WHERE staffid='$_SESSION[login_user2]';");
										$row=mysqli_fetch_assoc($result);
										
										echo "Staff ID : ".$row['staffid']; 
																
									}                                            
							?>
						</div>
						<div class="staffname">
							<?php
									if(isset($_SESSION['login_user2']))
									{
										$result=mysqli_query($connect,"SELECT * from staff WHERE staffid='$_SESSION[login_user2]';");
										$row=mysqli_fetch_assoc($result);
										echo "Staff Name : ".$row['staffname'];                         
									}                                            
							?>
						</div> 
						<form  action="weightexit.php" method="post" enctype="multipart/form-data" autocomplete="off">
							<div class="user_details">				
								<?php  
									$result=mysqli_query($connect,"SELECT * from `overall` WHERE vehicle_no='$_SESSION[vehicle_no]';");
									$row=mysqli_fetch_assoc($result);       
									
									if($row['vehicle_is']=='Full')
									{
										echo "<div  class='scroll'>";
										echo "<table class ='table'>";
										echo "<tr style='background-color: lightgreen;'>";

										echo "<th>"; echo "Vehicle Number"; echo "</th>";
										echo "<th>"; echo "Status"; echo "</th>";
										echo "<th>"; echo "Weight Of Product on Paper"; echo "</th>";
										echo "<th>"; echo "Weight of Vehicle before Unloading"; echo "</th>";
										echo "<th>"; echo "Weight of Vehicle after Unloading"; echo "</th>";
										
										echo "</tr>";

									
										echo "<tr style='background-color: white;'>";

										echo "<td>"; echo $row['vehicle_no']; echo "</td>";
										echo "<td>"; echo $row['status']; echo "</td>";
										echo "<td>"; echo $row['weight']; echo "</td>";
										echo "<td>"; echo $row['weight_in']; echo "</td>";
										echo "<td>"; echo $row['weight_out']; echo "</td>";
										
										echo "</tr>";
										$weightin=$row['weight_in'];
										$weightout=$row['weight_out'];
										$weight=$row['weight'];
										$finalweight=$weightin-$weightout;

										$final=$finalweight-$weight;
										echo "<tr style='background-color: white; font-size:40px; height:50px;'>";
											echo "<td style='font-size:30px;' colspan=5>"; echo "Weight Difference in Paper and Real : "; echo $final; echo " Kg"; echo "</td>";
										echo "</tr>";
											

										echo "</table>";
										echo "</div>";
									}

									if($row['vehicle_is']=='Empty')
									{
										echo "<div  class='scroll'>";
										echo "<table class ='table'>";
										echo "<tr style='background-color: lightgreen;'>";

										echo "<th>"; echo "Vehicle Number"; echo "</th>";
										echo "<th>"; echo "Status"; echo "</th>";
										echo "<th>"; echo "Customer Name"; echo "</th>";
										echo "<th>"; echo "Weight of Vehicle before Loading"; echo "</th>";
										echo "<th>"; echo "Weight of Vehicle after Loading"; echo "</th>";
										
										echo "</tr>";

									
										echo "<tr style='background-color: white;'>";

										echo "<td>"; echo $row['vehicle_no']; echo "</td>";
										echo "<td>"; echo $row['status']; echo "</td>";
										echo "<td>"; echo $row['customer_name']; echo "</td>";
										echo "<td>"; echo $row['weight_in']; echo "</td>";
										echo "<td>"; echo $row['weight_out']; echo "</td>";
										
										echo "</tr>";
										$weightin=$row['weight_in'];
										$weightout=$row['weight_out'];
										$finalweight=$weightout-$weightin;

										echo "<tr style='background-color: white; font-size:40px; height:50px;'>";
											echo "<td style='font-size:30px;' colspan=5>"; echo "Weight of the Product: "; echo $finalweight; echo " Kg"; echo "</td>";
										echo "</tr>";
											

										echo "</table>";
										echo "</div>";
									}
									?>

								<div class="btn">
									<div class="button">
										<input type="submit" name="submitweightpending" value="Wait">
									</div></div>
								<div class="btn">
									<div class="button">
										<input type="submit" name="submitweightexit" value="Verify">
									</div>
								</div>
								
							</div>
						</form>
					</div>
				</section>
			<?php
		}
		else
		{
			?>
				<script>
					window.location="../index.php";
				</script> 
			<?php
		}
	?>
	
</body>
</html>
