<?php
    include "connection.php";
	include "nav.php";

    if(isset($_POST['exit3']))
		{
            date_default_timezone_set("Asia/Kolkata");
            $currenttime=date("d-m-Y h:i:sa");

			$result=mysqli_query($connect,"SELECT * FROM `overall` WHERE `vehicle_no`='$_SESSION[vehicle3]'");
            $_row=mysqli_fetch_assoc($result);

            $pdf1=$_row['customer_name'];
            $pdf2=$_row['entry_date'];
            $pdf= $pdf1." (".$pdf2.")";

            mysqli_query($connect,"INSERT INTO `final` VALUES('$pdf','$_row[vehicle_is]','$_row[vehicle_no]','$_row[status]','$_row[place_from]','$_row[transport_name]','$_row[vehicle_type]','$_row[entry_gate_no]','Gate_3','$_row[entry_date]','$_row[entry_time]','$currenttime','$_row[customer_name]','$_row[challan_no]','$_row[weight]','$_row[weight_in]','$_row[weight_out]','$_row[driver_name]','$_row[driver_mobile]','$_row[challan_photo]','$_row[driver_photo]','$_row[driver_proof]','$_row[driver_sign]','$_row[remark]');");            mysqli_query($connect,"DELETE FROM `overall` WHERE `vehicle_no`='$_SESSION[vehicle3]'");
            ?>
                <script>
                    var stri="<?php echo $_SESSION['vehicle3']; ?>";
                    alert("Vehicle Number: "+stri);
                
                    window.location="exit3.php";
                </script>
            <?php
        }

?>