<?php
	session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<link rel="stylesheet" href="../../css/navbar/head_nav.css">

</head>
<body>
    <header>
		<nav class="navbar">

			<input type="checkbox" id="check">
			<label for="check">
				<i class="fas fa-bars" id="btn"></i>
				<i class="fas fa-times" id="cancel"></i>
			</label>

			<img class="logo" src="logo.png" alt="">

			<?php
				if(isset($_SESSION['gate']))
				{
					?>
						<ul>
							<li><a class="active" href="logout.php">Logout</a></li>
							<li><a href="#">Services</a></li>
							<li><a href="#">About</a></li>
							<li><a href="#">Contact</a></li>
						</ul>
					<?php
				}
				else
				{
					?>
						<ul>
								<li><a class="active" href="index.php">Login</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">About</a></li>
								<li><a href="#">Contact</a></li>
						</ul>
					<?php
				}
			?>

			
		</nav>
	</header>
	
</body>
</html>