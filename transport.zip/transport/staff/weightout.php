<?php
	include "connection.php";
	include "nav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WeightIn</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<link rel="stylesheet" href="weightall.css">
	
</head>
<body>

	<?php
		if(isset($_SESSION['login_user2'])){
			?>
				<section>
					<div class="container">

							<div>
								<a style="color:white;margin-right:25px; float:right; width:60px; background:blue; padding:5px; border:2px solid grey; border-radius:15px; text-align:center;" href="gateweight.php">Back</a>
							</div>
						
						
						<br><br><br>
						<div class="title">Weight Before Exit</div>
						<div class="staffid">
							<?php
									if(isset($_SESSION['login_user2']))
									{
										$result=mysqli_query($connect,"SELECT * from staff WHERE staffid='$_SESSION[login_user2]';");
										$row=mysqli_fetch_assoc($result);
										
										echo "Staff ID : ".$row['staffid']; 
																
									}                                            
							?>
						</div>
						<div class="staffname">
							<?php
									if(isset($_SESSION['login_user2']))
									{
										$result=mysqli_query($connect,"SELECT * from staff WHERE staffid='$_SESSION[login_user2]';");
										$row=mysqli_fetch_assoc($result);
										echo "Staff Name : ".$row['staffname'];                         
									}                                            
							?>
						</div> 
						<form action="" method="post">
							<div class="user_details">
								<div class="btn1">
									<div class="button">
										<input type="submit" name="search" value="View">
									</div>
								</div>
							</div>	
						</form>
						<?php

						if(isset($_POST['search']))
						{
							$search=mysqli_query($connect,"SELECT * FROM `overall` WHERE `weight_out`='0' && (`status`='Going for Loading' || `status`='Going for Unloaded')");
							
							if(mysqli_num_rows($search)==0)
							{
								?>
									<script>
										alert("No data is Available.");
									</script>
								<?php
								
							}
							else
							{
									echo "<div  class='scroll'>";
									echo "<table class ='table'>";
									echo "<tr style='background-color: lightblue;'>";

									echo "<th>"; echo "Entry Gate Number"; echo "</th>";
									echo "<th>"; echo "Vehicle Was"; echo "</th>";
									echo "<th>"; echo "Status"; echo "</th>";
									echo "<th>"; echo "Vehicle Number"; echo "</th>";
									echo "<th>"; echo "Vehicle Type"; echo "</th>";
									echo "<th>"; echo "Entry Date"; echo "</th>";
									echo "<th>"; echo "Entry Time"; echo "</th>";
									echo "<th>"; echo "Driver Name"; echo "</th>";
									echo "<th>"; echo "Driver Photo"; echo "</th>";
									
									echo "</tr>";

								while($row=mysqli_fetch_assoc($search))
								{
										echo "<tr style='background-color: white;'>";
										if($row['vehicle_is']=='Full')
										{
											$driverphoto="<img class='img-circle profile_img' height=80 width=80 src='vehiclefull/".$row['driver_photo']."'>";
											echo "<td>"; echo $row['entry_gate_no']; echo "</td>";									
											echo "<td>"; echo $row['vehicle_is']; echo "</td>";
											echo "<td>"; echo "Unloading (Yes/No)"; echo "</td>";
											echo "<td>"; echo $row['vehicle_no']; echo "</td>";
											echo "<td>"; echo $row['vehicle_type']; echo "</td>";
											echo "<td>"; echo $row['entry_date']; echo "</td>";
											echo "<td>"; echo $row['entry_time']; echo "</td>";
											echo "<td>"; echo $row['driver_name']; echo "</td>";
											echo "<td>"; echo $driverphoto; echo "</td>";
										}
										if($row['vehicle_is']=='Empty')
										{
											$driverphoto="<img class='img-circle profile_img' height=80 width=80 src='vehicleempty/".$row['driver_photo']."'>";
											echo "<td>"; echo $row['entry_gate_no']; echo "</td>";									
											echo "<td>"; echo $row['vehicle_is']; echo "</td>";
											echo "<td>"; echo "Loaded (Yes/No)"; echo "</td>";
											echo "<td>"; echo $row['vehicle_no']; echo "</td>";
											echo "<td>"; echo $row['vehicle_type']; echo "</td>";
											echo "<td>"; echo $row['entry_date']; echo "</td>";
											echo "<td>"; echo $row['entry_time']; echo "</td>";
											echo "<td>"; echo $row['driver_name']; echo "</td>";
											echo "<td>"; echo $driverphoto; echo "</td>";
										}
										
										
	
										echo "</tr>";

								}	
								echo "</table>";
								echo "</div>";
							}
						}

						?>
						<div class="title1"></div>
						<form  action="weightoutphp.php" method="post" enctype="multipart/form-data" autocomplete="off">
							<div class="user_details" id="input">				
								
								<div class="input-box" id="input1">
									<span class="details">Vehicle Number</span>
									<input type="text" name="vn1" placeholder="Enter Vehicle Number" required>
								</div>

								<div class="input-box" id="input2">
									<span class="details">Vehicle Weight</span>
									<input type="text" name="vweightout" placeholder="Enter Vehicle Weight" required>
								</div>

								<div class="btn">
									<div class="button">
										<input type="submit" name="submitweightout" value="Submit">
									</div>
									<div class="reset">
										<input type="reset" value="Reset">
									</div>
								</div>
								
							</div>
						</form>
						<script type="text/javascript">
							const input1 = document.querySelector("#input1");
							const fillinput1 = input1.querySelector("input");
							const input2 = document.querySelector("#input2");
							const fillinput2 = input2.querySelector("input");

							const speak = window.SpeechRecognition || window.webkitSpeechRecognition;

							if(speak){
								console.log("Browser support speech Recognition");
								input1.insertAdjacentHTML("beforeend",'<button type="button"><i class="fas fa-microphone-slash"></i></button>');
								const mic1 = input1.querySelector("button");
								const icon1 = mic1.querySelector("i");
								input2.insertAdjacentHTML("beforeend",'<button type="button"><i class="fas fa-microphone-slash"></i></button>');
								const mic2 = input2.querySelector("button");
								const icon2 = mic2.querySelector("i");

								const recog1 = new webkitSpeechRecognition();
								recog1.lang = "en-IN";
								const recog2 = new webkitSpeechRecognition();
								recog2.lang = "en-IN";
								

								mic1.addEventListener("click" , mic1Click);
								mic2.addEventListener("click" , mic2Click);

								function mic1Click(){
									if(icon1.classList.contains("fa-microphone-slash")){
										icon1.classList.remove("fa-microphone-slash");
										icon1.classList.add("fa-microphone");
										recog1.start();
										fillinput1.focus();
										start1();

									}
									else{
										icon1.classList.remove("fa-microphone");
										icon1.classList.add("fa-microphone-slash");
										recog1.stop();
										fillinput1.focus();
									}
								}
								function mic2Click(){
									if(icon2.classList.contains("fa-microphone-slash")){
										icon2.classList.remove("fa-microphone-slash");
										icon2.classList.add("fa-microphone");
										recog2.start();
										fillinput2.focus();
										start2();
									}
									else{
										icon2.classList.remove("fa-microphone");
										icon2.classList.add("fa-microphone-slash");
										recog2.stop();
										fillinput2.focus();
									}
								}
								
								
								function start1()
								{
									recog1.addEventListener("result", result1);	
										function result1(event){
											const transcript1 = event.results[0][0].transcript;
											fillinput1.value = transcript1;
										}
								}

								function start2()
								{
									recog2.addEventListener("result", result2);	
										function result2(event){
											const transcript2 = event.results[0][0].transcript;
											fillinput2.value = transcript2;
										}
								}

																
							}
							else{
								console.log("Browser does not support speech Recognition");
							}
						</script>
					</div>
				</section>
			<?php
		}
		else
		{
			?>
				<script>
					window.location="../index.php";
				</script> 
			<?php
		}
	?>
</body>
</html>