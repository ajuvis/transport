<?php
	session_start();
	include "connection.php";
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<style>
		* {
	margin: 0;
	padding: 0;
	list-style: none;
	text-decoration: none;
}

body{
	background: #71b7e6;
	background-size: cover;
	background-position-x: 50%;
	height: 100vh;
	/*overflow: hidden;*/
}

 /****** Header Section ******/

.navbar{
	height: 80px;
	background: #2c3e50;
}

.logo{

	width: 170px;
	height: 60px;
	position: absolute;
	margin-top: 10px;
	margin-left: 120px;
	border-radius: 10px;
}

.navbar ul{
	float: right;
	margin-right: 70px;
}

.navbar ul li{
	margin: 0 20px;
	display: inline-block;
	line-height: 80px;
}

.navbar ul li a{
	position: relative;
	color: white;
	font-size: 20px;
	padding: 5px 10px;
	text-transform: uppercase;
	font-family: 'Roboto', sans-serif;
	transition: .5s;
}

.navbar ul li a:before{
	position: absolute;
	content: '';
	left: 0;
	bottom: 0;
	height: 3px;
	width: 100%;
	background:blue;
	transform: scaleX(0);
	transform-origin: right;
	transition: transform .4s linear;
}

.navbar ul li a:hover::before{
	transform: scaleX(1);
	transform-origin: left;
}

label #btn,
label #cancel{
	color: white;
	font-size: 30px;
	float: right;
	line-height: 80px;
	margin-right: 40px;
	cursor: pointer;
	display: none;
}

#check{
	display: none;
}

@media (max-width: 1504px){
	nav .logo{
		left: -3%;
	}
}

@media (max-width: 1080px){
	nav .logo{
		left: -5%;
		top: 6px;;
		width: 130px;
	    height: 50px;		
	}
	.navbar ul li a{
		font-size: 17px;
	}
}


@media (max-width: 900px){
	label #btn{
		display: block;
	}
	ul{
		position:  fixed;
		width: 100%;
		height: 100vh;
		background: #34495e;
		top: 80px;
		left: -100%;
		text-align: center;
		transition: all .5s;
	}
	.navbar ul li{
		display: block;
		margin: 50px 0;
		line-height: 30px;
	}

	.navbar ul li a{
		font-size: 20px;
	}

	#check:checked ~ ul{
		left: 0;
	}

	#check:checked ~ label #btn{
		display: none;
	}

	#check:checked ~ label #cancel{
		display: block;
	}

	nav .logo{
		left: -10%;
		top: 6px;;
		width: 130px;
	    height: 50px;		
	}
	.navbar ul li a{
		font-size: 17px;
	}

}

@media (max-width: 720px){
	label #btn{
		display: block;
	}
	ul{
		position:  fixed;
		width: 100%;
		height: 100vh;
		background: #34495e;
		top: 80px;
		left: -100%;
		text-align: center;
		transition: all .5s;
	}
	.navbar ul li{
		display: block;
		margin: 50px 0;
		line-height: 30px;
	}

	.navbar ul li a{
		font-size: 20px;
	}

	#check:checked ~ ul{
		left: 0;
	}

	#check:checked ~ label #btn{
		display: none;
	}

	#check:checked ~ label #cancel{
		display: block;
	}

	nav .logo{
		left: -10%;
		top: 6px;;
		width: 100px;
	    height: 45px;		
	}
	.navbar ul li a{
		font-size: 15px;
	}

}
	</style>

</head>
<body>
    <header>
		<nav class="navbar">

			<input type="checkbox" id="check">
			<label for="check">
				<i class="fas fa-bars" id="btn"></i>
				<i class="fas fa-times" id="cancel"></i>
			</label>

			<img class="logo" src="../image/logo.png" alt="Transport">

			<?php
				if(isset($_SESSION['login_user1']))
				{
					?>
						<ul>
							<li><a class="active" href="logout.php">Logout</a></li>
							<li><a href="services.php">Services</a></li>
							<li><a href="about.php">About</a></li>
							<li><a href="contact.php">Contact</a></li>
						</ul>
					<?php
				}
				else{
					if(isset($_SESSION['login_user2']))
					{
						?>
							<ul>
								<li><a class="active" href="logout.php">Logout</a></li>
								<li><a href="services.php">Services</a></li>
								<li><a href="about.php">About</a></li>
								<li><a href="contact.php">Contact</a></li>
							</ul>
						<?php
					}
					else
					{
						?>
							<ul>
									<li><a class="active" href="index.php">Login</a></li>
									<li><a href="services.php">Services</a></li>
									<li><a href="about.php">About</a></li>
									<li><a href="contact.php">Contact</a></li>
							</ul>
						<?php
					}
				}
				
				
			?>

			
		</nav>
	</header>
	
</body>
</html>