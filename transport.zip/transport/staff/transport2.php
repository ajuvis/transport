<?php
	include "connection.php";
	include "nav.php";
      
		if(isset($_POST['submitgate2']))
		{
			if($_POST['load']=="Full")
			{
				mysqli_query($connect,"INSERT INTO `vehiclefull` VALUES ('','Full','Pending','$_POST[customername]','$_POST[from]','$_POST[tn1]','$_POST[vt1]','$_POST[vn1]','Gate_2');");
				$result=mysqli_query($connect,"SELECT vehicle_no from `vehiclefull` WHERE vehicle_no='$_POST[vn1]';");
				$row=mysqli_fetch_assoc($result);   
				?>
					<script>
						var stri="<?php echo $row['vehicle_no']; ?>";
						alert("Vehicle Number: "+stri);
					
						window.location="gate2.php";
					</script>
				<?php
			}
			if($_POST['load']=="Empty")
			{
				mysqli_query($connect,"INSERT INTO `vehicleempty` VALUES ('','Empty','Pending','$_POST[customername]','$_POST[from]','$_POST[tn1]','$_POST[vt1]','$_POST[vn1]','Gate_2');");
				$result=mysqli_query($connect,"SELECT vehicle_no from `vehicleempty` WHERE vehicle_no='$_POST[vn1]';");
				$row=mysqli_fetch_assoc($result);   
				?>
					<script>
						var stri="<?php echo $row['vehicle_no']; ?>";
						alert("Vehicle Number: "+stri);
					
						window.location="gate2.php";
					</script>
				<?php
			}
			if($_POST['load']=="NA")
			{
				?>
					<script>
						alert("Please select Vehicle In option.");
					
						window.location="gate2.php";
					</script>
				<?php
			}
		}
?>