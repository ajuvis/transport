<?php
	include "connection.php";
	include "nav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gate</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<link rel="stylesheet" href="allentry.css">
</head>
<body>
 
		<?php
			if(isset($_SESSION['login_user1'])){
				?>
					<section>		
						<div class="container">
								<div>
									<a style="color:white;margin-right:25px; float:right; width:60px; background:blue; padding:5px; border:2px solid grey; border-radius:15px; text-align:center;" href="gate.php">Back</a>
								</div>

							<br><br><br>
							<div class="title">Transport Verification</div>
							<div class="staffid">
								<?php
										if(isset($_SESSION['login_user1']))
										{
											$result=mysqli_query($connect,"SELECT * from staff WHERE staffid='$_SESSION[login_user1]';");
											$row=mysqli_fetch_assoc($result);
											
											echo "Staff ID : ".$row['staffid']; 
																	
										}                                            
								?>
							</div>
							<div class="staffname">
								<?php
										if(isset($_SESSION['login_user1']))
										{
											$result=mysqli_query($connect,"SELECT * from staff WHERE staffid='$_SESSION[login_user1]';");
											$row=mysqli_fetch_assoc($result);
											echo "Staff Name : ".$row['staffname'];                         
										}                                            
								?>
							</div> 
							<form action="" method="post">
								<div class="user_details">
									<div class="btn1">
										<div class="button">
											<input type="submit" name="search" value="Status">
										</div>
									</div>
								</div>	
							</form>
							<?php

						if(isset($_POST['search']))
						{
							$search=mysqli_query($connect,"SELECT * FROM `vehiclefull` WHERE `entry_gate_no`='Gate_3'");
							$search1=mysqli_query($connect,"SELECT * FROM `vehicleempty` WHERE `entry_gate_no`='Gate_3'");

							if(mysqli_num_rows($search)==0 && mysqli_num_rows($search1)==0)
							{
								?>
									<script>
										alert("No data is Available.");
									</script>
								<?php
								
							}
							else
							{
									echo "<div  class='scroll'>";
									echo "<table class ='table'>";
									echo "<tr style='background-color: lightgreen;'>";

									echo "<th>"; echo "Entry ID"; echo "</th>";
									echo "<th>"; echo "Vehicle_Is"; echo "</th>";
									echo "<th>"; echo "Status"; echo "</th>";
									echo "<th>"; echo "Customer Name"; echo "</th>";
									echo "<th>"; echo "Place From"; echo "</th>";
									echo "<th>"; echo "Transport Name"; echo "</th>";
									echo "<th>"; echo "Vehicle Type"; echo "</th>";
									echo "<th>"; echo "Vehicle Number"; echo "</th>";
									echo "<th>"; echo "Entry Gate Number"; echo "</th>";
									
									
									echo "</tr>";

								while($row=mysqli_fetch_assoc($search))
								{
										echo "<tr style='background-color: white;'>";

										echo "<td>"; echo $row['ID']; echo "</td>";
										echo "<td>"; echo $row['vehicle_is']; echo "</td>";
										echo "<td>"; echo $row['status']; echo "</td>";
										echo "<td>"; echo $row['customer_name']; echo "</td>";
										echo "<td>"; echo $row['place_from']; echo "</td>";
										echo "<td>"; echo $row['transport_name']; echo "</td>";
										echo "<td>"; echo $row['vehicle_type']; echo "</td>";
										echo "<td>"; echo $row['vehicle_no']; echo "</td>";
										echo "<td>"; echo $row['entry_gate_no']; echo "</td>";
										echo "</tr>";

								}	
								while($row1=mysqli_fetch_assoc($search1))
								{
										echo "<tr style='background-color: white;'>";

										echo "<td>"; echo $row1['ID']; echo "</td>";
										echo "<td>"; echo $row1['vehicle_is']; echo "</td>";
										echo "<td>"; echo $row1['status']; echo "</td>";
										echo "<td>"; echo $row1['customer_name']; echo "</td>";
										echo "<td>"; echo $row1['place_from']; echo "</td>";
										echo "<td>"; echo $row1['transport_name']; echo "</td>";
										echo "<td>"; echo $row1['vehicle_type']; echo "</td>";
										echo "<td>"; echo $row1['vehicle_no']; echo "</td>";
										echo "<td>"; echo $row1['entry_gate_no']; echo "</td>";
										echo "</tr>";

								}	

								echo "</table>";
								echo "</div>";
							}
						}

							?>
							<div class="title1"></div>
							<form action="transport3.php" method="post" enctype="multipart/form-data" autocomplete="off">
								<div class="user_details">				
								<div class="input-box">
									<span class="details">Vehicle Is</span>
									<select name="load" id="">
										<option value="NA">-----select-----</option>
										<option value="Full">Full</option>
										<option value="Empty">Empty</option>
									</select>
								</div>
								<div class="input-box" id="input1">
									<span class="details">Customer Name</span>
									<input type="text" name="customername" placeholder="Enter Customer Name" required>
								</div>
								<div class="input-box" id="input2">
									<span class="details">Place From</span>
									<input type="text" name="from" placeholder="Enter Place From" required>
								</div>				
								<div class="input-box" id="input3">
									<span class="details">Transport Name</span>
									<input type="text" name="tn1" placeholder="Enter Transport Name" required>
								</div>
								<div class="input-box" id="input4">
									<span class="details">Vehicle Type</span>
									<input type="text" name="vt1" placeholder="Enter Vehicle Type" required>
								</div>
								<div class="input-box" id="input5">
									<span class="details">Vehicle Number</span>
									<input type="text" name="vn1" placeholder="Enter Vehicle Number" required>
								</div>
									<div class="btn">
										<div class="button">
											<input type="submit" name="submitgate3" value="Submit">
										</div>
										<div class="reset">
											<input type="reset" value="Reset">
										</div>
									</div>									
								</div>
							</form>

						<script type="text/javascript">
							const input1 = document.querySelector("#input1");
							const fillinput1 = input1.querySelector("input");

							const input2 = document.querySelector("#input2");
							const fillinput2 = input2.querySelector("input");

							const input3 = document.querySelector("#input3");
							const fillinput3 = input3.querySelector("input");

							const input4 = document.querySelector("#input4");
							const fillinput4 = input4.querySelector("input");

							const input5 = document.querySelector("#input5");
							const fillinput5 = input5.querySelector("input");

							const speak = window.SpeechRecognition || window.webkitSpeechRecognition;

							if(speak){
								console.log("Browser support speech Recognition");
								input1.insertAdjacentHTML("beforeend",'<button type="button"><i class="fas fa-microphone-slash"></i></button>');
								const mic1 = input1.querySelector("button");
								const icon1 = mic1.querySelector("i");

								input2.insertAdjacentHTML("beforeend",'<button type="button"><i class="fas fa-microphone-slash"></i></button>');
								const mic2 = input2.querySelector("button");
								const icon2 = mic2.querySelector("i");

								input3.insertAdjacentHTML("beforeend",'<button type="button"><i class="fas fa-microphone-slash"></i></button>');
								const mic3 = input3.querySelector("button");
								const icon3 = mic3.querySelector("i");

								input4.insertAdjacentHTML("beforeend",'<button type="button"><i class="fas fa-microphone-slash"></i></button>');
								const mic4 = input4.querySelector("button");
								const icon4 = mic4.querySelector("i");

								input5.insertAdjacentHTML("beforeend",'<button type="button"><i class="fas fa-microphone-slash"></i></button>');
								const mic5 = input5.querySelector("button");
								const icon5 = mic5.querySelector("i");


								const recog1 = new webkitSpeechRecognition();
								recog1.lang = "en-IN";
								const recog2 = new webkitSpeechRecognition();
								recog2.lang = "en-IN";
								const recog3 = new webkitSpeechRecognition();
								recog3.lang = "en-IN";
								const recog4 = new webkitSpeechRecognition();
								recog4.lang = "en-IN";
								const recog5 = new webkitSpeechRecognition();
								recog5.lang = "en-IN";

								mic1.addEventListener("click" , mic1Click);
								mic2.addEventListener("click" , mic2Click);
								mic3.addEventListener("click" , mic3Click);
								mic4.addEventListener("click" , mic4Click);
								mic5.addEventListener("click" , mic5Click);

								function mic1Click(){
									if(icon1.classList.contains("fa-microphone-slash")){
										icon1.classList.remove("fa-microphone-slash");
										icon1.classList.add("fa-microphone");
										recog1.start();
										fillinput1.focus();
										start1();

									}
									else{
										icon1.classList.remove("fa-microphone");
										icon1.classList.add("fa-microphone-slash");
										recog1.stop();
										fillinput1.focus();
									}
								}
								function mic2Click(){
									if(icon2.classList.contains("fa-microphone-slash")){
										icon2.classList.remove("fa-microphone-slash");
										icon2.classList.add("fa-microphone");
										recog2.start();
										fillinput2.focus();
										start2();
									}
									else{
										icon2.classList.remove("fa-microphone");
										icon2.classList.add("fa-microphone-slash");
										recog2.stop();
										fillinput2.focus();
									}
								}
								function mic3Click(){
									if(icon3.classList.contains("fa-microphone-slash")){
										icon3.classList.remove("fa-microphone-slash");
										icon3.classList.add("fa-microphone");
										recog3.start();
										fillinput3.focus();
										start3();
									}
									else{
										icon3.classList.remove("fa-microphone");
										icon3.classList.add("fa-microphone-slash");
										recog3.stop();
										fillinput3.focus();
									}
								}
								function mic4Click(){
									if(icon4.classList.contains("fa-microphone-slash")){
										icon4.classList.remove("fa-microphone-slash");
										icon4.classList.add("fa-microphone");
										recog4.start();
										fillinput4.focus();
										start4();
									}
									else{
										icon4.classList.remove("fa-microphone");
										icon4.classList.add("fa-microphone-slash");
										recog4.stop();
										fillinput4.focus();
									}
								}
								function mic5Click(){
									if(icon5.classList.contains("fa-microphone-slash")){
										icon5.classList.remove("fa-microphone-slash");
										icon5.classList.add("fa-microphone");
										recog5.start();
										fillinput5.focus();
										start5();
									}
									else{
										icon5.classList.remove("fa-microphone");
										icon5.classList.add("fa-microphone-slash");
										recog5.stop();
										fillinput5.focus();
									}
								}

								
								function start1()
								{
									recog1.addEventListener("result", result1);	
										function result1(event){
											const transcript1 = event.results[0][0].transcript;
											fillinput1.value = transcript1;
										}
								}

								function start2()
								{
									recog2.addEventListener("result", result2);	
										function result2(event){
											const transcript2 = event.results[0][0].transcript;
											fillinput2.value = transcript2;
										}
								}

								function start3()
								{
									recog3.addEventListener("result", result3);
										function result3(event){
											const transcript3 = event.results[0][0].transcript;
											fillinput3.value = transcript3;
										}
								}

								function start4()
								{
									recog4.addEventListener("result", result4);
										function result4(event){
											const transcript4 = event.results[0][0].transcript;
											fillinput4.value = transcript4;
										}
								}

								function start5()
								{
									recog5.addEventListener("result", result5);
										function result5(event){
											const transcript5 = event.results[0][0].transcript;
											fillinput5.value = transcript5;
										}
								}
																
							}
							else{
								console.log("Browser does not support speech Recognition");
							}
						</script>
						</div>
					</section>
				<?php
			}
			else
			{
				?>
					<script>
						window.location="../index.php";
					</script> 
				<?php
			}
		?>
	
</body>
</html>