<?php
	include "connection.php";
	include "nav.php";
      
		if(isset($_POST['submitdriver1']))
		{
            $count1=0;
            $count2=0;
            $result1=mysqli_query($connect,"SELECT * from `vehiclefull` where vehicle_no='$_POST[vn1]';");
            $result2=mysqli_query($connect,"SELECT * from `vehicleempty` where vehicle_no='$_POST[vn1]';");
            $row=mysqli_fetch_assoc($result1);
            $row2=mysqli_fetch_assoc($result2);
            
            $count1=mysqli_num_rows($result1);
            $count2=mysqli_num_rows($result2);

            if(($count1==0) && ($count2==0))
            {
                    ?>           
						<script type="text/javascript">
						alert("The vehicle number doesn't match.");
                        window.location="driver.php";
						</script>      
					<?php
            }
            else
            {
                date_default_timezone_set("Asia/Kolkata");
                $currentdate=date("d-m-Y");
                $currenttime=date("h:i:sa");
                
                if($count1>0)
                {
                    $vehicle_no=$row['vehicle_no'];
                    move_uploaded_file($_FILES['file4']['tmp_name'],"vehiclefull/".$_FILES['file4']['name']);
                    $pic4=$_FILES['file4']['name'];
                    move_uploaded_file($_FILES['file5']['tmp_name'],"vehiclefull/".$_FILES['file5']['name']);
                    $pic5=$_FILES['file5']['name'];
                    move_uploaded_file($_FILES['file6']['tmp_name'],"vehiclefull/".$_FILES['file6']['name']);
                    $pic6=$_FILES['file6']['name'];
                    move_uploaded_file($_FILES['file7']['tmp_name'],"vehiclefull/".$_FILES['file7']['name']);
                    $pic7=$_FILES['file7']['name'];

                    mysqli_query($connect,"INSERT INTO `overall` VALUES('$row[vehicle_no]','OK','$row[vehicle_is]','$row[place_from]','Not Allow','$row[transport_name]','$row[vehicle_type]','$row[entry_gate_no]','','$currentdate','$currenttime','','$row[customer_name]','$_POST[challan1]','$_POST[wop1]','0','0','$_POST[dname1]','$_POST[mobile1]','$pic4','$pic5','$pic6','$pic7','');");
                    mysqli_query($connect,"DELETE From `vehiclefull` where vehicle_no='$_POST[vn1]'");  
                    ?>
                        <script>
                            var stri="<?php echo $vehicle_no; ?>";
                            alert("Vehicle Number: "+stri);
                        
                            window.location="driver.php";
                        </script>
                    <?php
                }

                if($count2>0)
                {
           
                    $vehicle_no1=$row2['vehicle_no'];
                   
                    move_uploaded_file($_FILES['file5']['tmp_name'],"vehicleempty/".$_FILES['file5']['name']);
                    $pic5=$_FILES['file5']['name'];
                    move_uploaded_file($_FILES['file6']['tmp_name'],"vehicleempty/".$_FILES['file6']['name']);
                    $pic6=$_FILES['file6']['name'];
                    move_uploaded_file($_FILES['file7']['tmp_name'],"vehicleempty/".$_FILES['file7']['name']);
                    $pic7=$_FILES['file7']['name'];

                    mysqli_query($connect,"INSERT INTO `overall` VALUES('$row2[vehicle_no]','OK','$row2[vehicle_is]','$row2[place_from]','Not Allow','$row2[transport_name]','$row2[vehicle_type]','$row2[entry_gate_no]','','$currentdate','$currenttime','','$row2[customer_name]','$_POST[challan1]','$_POST[wop1]','0','0','$_POST[dname1]','$_POST[mobile1]','','$pic5','$pic6','$pic7','');");
                    mysqli_query($connect,"DELETE From `vehicleempty` where vehicle_no='$_POST[vn1]'");  
                    ?>
                        <script>
                            var stri="<?php echo $vehicle_no1; ?>";
                            alert("Vehicle Number: "+stri);
                        
                            window.location="driver.php";
                        </script>
                    <?php
                }

            }

			
		}
?>
