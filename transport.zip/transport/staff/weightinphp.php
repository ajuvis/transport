<?php
    include "connection.php";
	include "nav.php";

    if(isset($_POST['submitweight']))
		{
			$count=0;
            $result2=mysqli_query($connect,"SELECT * from `overall` where vehicle_no='$_POST[vn1]';");
            $row=mysqli_fetch_assoc($result2);
            
            $count=mysqli_num_rows($result2);

            if($count==0)
            {
                    ?>           
						<script type="text/javascript">
						alert("The vehicle number doesn't match.");
                        window.location="weightin.php";
						</script>      
					<?php
            }
            else
            {
                if($row['vehicle_is']=='Empty')
                {
                    mysqli_query($connect,"UPDATE `overall` SET `weight_in`='$_POST[vweight]', `status`='Going for Loading' WHERE vehicle_no='$_POST[vn1]';");
                    ?>
                        <script>
                            var stri="<?php echo $row['vehicle_no']; ?>";
                            alert("Please Go for Loading ----- \nVehicle Number: "+stri);
                        
                            window.location="weightin.php";
                        </script>
                     <?php

                }  
                if($row['vehicle_is']=='Full')
                {
                    mysqli_query($connect,"UPDATE `overall` SET `weight_in`='$_POST[vweight]', `status`='Going for Unloaded' WHERE vehicle_no='$_POST[vn1]';");
                    ?>
                        <script>
                            var stri="<?php echo $row['vehicle_no']; ?>";
                            alert("Please Go for Unloading ----- \nVehicle Number: "+stri);
                        
                            window.location="weightin.php";
                        </script>
                     <?php

                }  
                
            }
		}

?>