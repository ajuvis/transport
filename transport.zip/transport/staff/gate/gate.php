<?php
	include "../../connection/connection.php";
	include "../header/g_nav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gate</title>
	 <!-- CSS only -->
	 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
   <!-- JavaScript Bundle with Popper -->
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
   
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<link rel="stylesheet" href="../gate1.css">
</head>
<body>
		<?php
			if(isset($_SESSION['gate']))
			{
				?>
					<div class="container">
						<form action="" method="post">
							<div class="box">
								<h1>Gate 1 </h1>				
								<div class="select">
									<input type="submit" name="transport1" value="Transport Verification">
									<input type="submit" name="driver" value="Driver Verification">
									<input type="submit" name="exit1" value="Exit Verification">
								</div>				
							</div>
							<div class="box">
								<h1>Gate 2 </h1>
								<div class="select">
									<input type="submit" name="transport2" value="Transport Verification">
									<input type="submit" name="driver" value="Driver Verification">
									<input type="submit" name="exit2" value="Exit Verification">
								</div>
							</div>
							<div class="box">
								<h1>Gate 3 </h1>
								<div class="select">
									<input type="submit" name="transport3" value="Transport Verification">
									<input type="submit" name="driver" value="Driver Verification">
									<input type="submit" name="exit3" value="Exit Verification">
								</div>
							</div>
						</form>
					</div>
				<?php
			}
			else{
				?>
					<script>
						window.location="../index.php";
					</script> 
				<?php
			}
		?>	
	<?php 
	
		if(isset($_POST['transport1'])){
			?>
			<script type="text/javascript">
				window.location="gate1.php"; 
			</script>
			<?php
		}
		if(isset($_POST['transport2'])){
			?>
			<script type="text/javascript">
				window.location="gate2.php"; 
			</script>
			<?php
		}
		if(isset($_POST['transport3'])){
			?>
			<script type="text/javascript">
				window.location="gate3.php"; 
			</script>
			<?php
		}
		if(isset($_POST['driver'])){
			?>
			<script type="text/javascript">
				window.location="driver.php"; 
			</script>
			<?php
		}
		if(isset($_POST['exit1'])){
			?>
			<script type="text/javascript">
				window.location="exit1.php"; 
			</script>
			<?php
		}
		if(isset($_POST['exit2'])){
			?>
			<script type="text/javascript">
				window.location="exit2.php"; 
			</script>
			<?php
		}
		if(isset($_POST['exit3'])){
			?>
			<script type="text/javascript">
				window.location="exit3.php"; 
			</script>
			<?php
		}
		
	?>
</body>
</html>