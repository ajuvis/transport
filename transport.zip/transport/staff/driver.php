<?php
	include "connection.php";
	include "nav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver1</title>	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.9.0/css/all.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<link rel="stylesheet" href="driver.css">
</head>
<body>

	<?php
		if(isset($_SESSION['login_user1'])){
			?>
				<section>	
					<div class="container">
							<div>
								<a style="color:white;margin-right:25px; float:right; width:60px; background:blue; padding:5px; border:2px solid grey; border-radius:15px; text-align:center;" href="gate.php">Back</a>
							</div>
						
						
						<br><br><br>
						<div class="title">Driver Verification</div>
						<div class="staffid">
							<?php
									if(isset($_SESSION['login_user1']))
									{
										$result=mysqli_query($connect,"SELECT * from staff WHERE staffid='$_SESSION[login_user1]';");
										$row=mysqli_fetch_assoc($result);
										
										echo "Staff ID : ".$row['staffid']; 
																
									}                                            
							?>
						</div>
						<div class="staffname">
							<?php
									if(isset($_SESSION['login_user1']))
									{
										$result=mysqli_query($connect,"SELECT * from staff WHERE staffid='$_SESSION[login_user1]';");
										$row=mysqli_fetch_assoc($result);
										echo "Staff Name : ".$row['staffname'];                         
									}                                            
							?>
						</div> 
						<form action="entrygate.php" method="post" enctype="multipart/form-data" autocomplete="off">
							<div class="user_details" id="input">
							
								<div class="input-box" id="input1">
									<span class="details">Vehicle Number</span>
									<input type="text" name="vn1" placeholder="Enter Vehicle Number" required>
								</div>

							

								<div class="input-box" id="input2">
									<span class="details">Challan No</span>
									<input type="text" name="challan1" placeholder="Enter Challan No" >
								</div>
								
								<div class="input-box" id="input3">
									<span class="details">Weight Of Product</span>
									<input type="text" name="wop1" placeholder="Weight of Product" required>
								</div>

								<div class="input-box" id="input4">
									<span class="details">Driver Name</span>
									<input type="text" name="dname1" placeholder="Enter Driver Name" required>
								</div>
								<div class="input-box" id="input5">
									<span class="details">Driver Mobile No.</span>
									<input type="text" name="mobile1" placeholder="Enter Mobile No" required>
								</div>
								
								<div class="input-box">
									<span class="details">Delivery Challan Photo</span>
									<input type="file" name="file4" placeholder="" >
								</div>
								<div class="input-box">
									<span class="details">Driver Photo</span>
									<input type="file" name="file5" placeholder="" required>
								</div>
								<div class="input-box">
									<span class="details">Driver ID Proof</span>
									<input type="file" name="file6" placeholder="Enter Driver ID Proof" required>
								</div>
								<div class="input-box">
									<span class="details">Driver Sign.</span>
									<input type="file" name="file7" placeholder="" required>
								</div>
								<div class="btn">
									<div class="button">
										<input type="submit" name="submitdriver1" value="Submit">
									</div>
									<div class="reset">
										<input type="reset" value="Reset">
									</div>
								</div>
								
							</div>
						</form>

						<script type="text/javascript">
							const input1 = document.querySelector("#input1");
							const fillinput1 = input1.querySelector("input");
							const input2 = document.querySelector("#input2");
							const fillinput2 = input2.querySelector("input");
							const input3 = document.querySelector("#input3");
							const fillinput3 = input3.querySelector("input");
							const input4 = document.querySelector("#input4");
							const fillinput4 = input4.querySelector("input");
							const input5 = document.querySelector("#input5");
							const fillinput5 = input5.querySelector("input");

							const speak = window.SpeechRecognition || window.webkitSpeechRecognition;

							if(speak){
								console.log("Browser support speech Recognition");


								input1.insertAdjacentHTML("beforeend",'<button type="button"><i class="fas fa-microphone-slash"></i></button>');
								const mic1 = input1.querySelector("button");
								const icon1 = mic1.querySelector("i");

								input2.insertAdjacentHTML("beforeend",'<button type="button"><i class="fas fa-microphone-slash"></i></button>');
								const mic2 = input2.querySelector("button");
								const icon2 = mic2.querySelector("i");

								input3.insertAdjacentHTML("beforeend",'<button type="button"><i class="fas fa-microphone-slash"></i></button>');
								const mic3 = input3.querySelector("button");
								const icon3 = mic3.querySelector("i");

								input4.insertAdjacentHTML("beforeend",'<button type="button"><i class="fas fa-microphone-slash"></i></button>');
								const mic4 = input4.querySelector("button");
								const icon4 = mic4.querySelector("i");

								input5.insertAdjacentHTML("beforeend",'<button type="button"><i class="fas fa-microphone-slash"></i></button>');
								const mic5 = input5.querySelector("button");
								const icon5 = mic5.querySelector("i");



								const recog1 = new webkitSpeechRecognition();
								recog1.lang = "en-IN";
								const recog2 = new webkitSpeechRecognition();
								recog2.lang = "en-IN";
								const recog3 = new webkitSpeechRecognition();
								recog3.lang = "en-IN";
								const recog4 = new webkitSpeechRecognition();
								recog4.lang = "en-IN";
								const recog5 = new webkitSpeechRecognition();
								recog5.lang = "en-IN";

								mic1.addEventListener("click" , mic1Click);
								mic2.addEventListener("click" , mic2Click);
								mic3.addEventListener("click" , mic3Click);
								mic4.addEventListener("click" , mic4Click);
								mic5.addEventListener("click" , mic5Click);

								function mic1Click(){
									if(icon1.classList.contains("fa-microphone-slash")){
										icon1.classList.remove("fa-microphone-slash");
										icon1.classList.add("fa-microphone");
										recog1.start();
										fillinput1.focus();
										start1();

									}
									else{
										icon1.classList.remove("fa-microphone");
										icon1.classList.add("fa-microphone-slash");
										recog1.stop();
										fillinput1.focus();
									}
								}
								function mic2Click(){
									if(icon2.classList.contains("fa-microphone-slash")){
										icon2.classList.remove("fa-microphone-slash");
										icon2.classList.add("fa-microphone");
										recog2.start();
										fillinput2.focus();
										start2();
									}
									else{
										icon2.classList.remove("fa-microphone");
										icon2.classList.add("fa-microphone-slash");
										recog2.stop();
										fillinput2.focus();
									}
								}
								function mic3Click(){
									if(icon3.classList.contains("fa-microphone-slash")){
										icon3.classList.remove("fa-microphone-slash");
										icon3.classList.add("fa-microphone");
										recog3.start();
										fillinput3.focus();
										start3();
									}
									else{
										icon3.classList.remove("fa-microphone");
										icon3.classList.add("fa-microphone-slash");
										recog3.stop();
										fillinput3.focus();
									}
								}
								function mic4Click(){
									if(icon4.classList.contains("fa-microphone-slash")){
										icon4.classList.remove("fa-microphone-slash");
										icon4.classList.add("fa-microphone");
										recog4.start();
										fillinput4.focus();
										start4();
									}
									else{
										icon4.classList.remove("fa-microphone");
										icon4.classList.add("fa-microphone-slash");
										recog4.stop();
										fillinput4.focus();
									}
								}
								function mic5Click(){
									if(icon5.classList.contains("fa-microphone-slash")){
										icon5.classList.remove("fa-microphone-slash");
										icon5.classList.add("fa-microphone");
										recog5.start();
										fillinput5.focus();
										start5();
									}
									else{
										icon5.classList.remove("fa-microphone");
										icon5.classList.add("fa-microphone-slash");
										recog5.stop();
										fillinput5.focus();
									}
								}

								
								function start1()
								{
									recog1.addEventListener("result", result1);	
										function result1(event){
											const transcript1 = event.results[0][0].transcript;
											fillinput1.value = transcript1;
										}
								}

								function start2()
								{
									recog2.addEventListener("result", result2);	
										function result2(event){
											const transcript2 = event.results[0][0].transcript;
											fillinput2.value = transcript2;
										}
								}

								function start3()
								{
									recog3.addEventListener("result", result3);
										function result3(event){
											const transcript3 = event.results[0][0].transcript;
											fillinput3.value = transcript3;
										}
								}

								function start4()
								{
									recog4.addEventListener("result", result4);
										function result4(event){
											const transcript4 = event.results[0][0].transcript;
											fillinput4.value = transcript4;
										}
								}

								function start5()
								{
									recog5.addEventListener("result", result5);
										function result5(event){
											const transcript5 = event.results[0][0].transcript;
											fillinput5.value = transcript5;
										}
								}

																
							}
							else{
								console.log("Browser does not support speech Recognition");
							}
						</script>

					</div>
				</section>
			<?php
		}
		else
		{
			?>
				<script>
					window.location="../index.php";
				</script> 
			<?php
		}
	?>
 
	
	
</body>
</html>