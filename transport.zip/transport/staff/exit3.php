<?php
	include "connection.php";
	include "nav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exit Gate</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="exit.css">
</head>
<body>

	<?php
		if(isset($_SESSION['login_user1'])){
			?>
				<section>
					<div class="container">
					
							<div>
								<a style="color:white;margin-right:25px; float:right; width:60px; background:blue; padding:5px; border:2px solid grey; border-radius:15px; text-align:center;" href="gate.php">Back</a>
							</div>
						
						
						<br>
						<div class="title">Exit Process</div>
						<div class="staffid">
							<?php
									if(isset($_SESSION['login_user1']))
									{
										$result=mysqli_query($connect,"SELECT * from staff WHERE staffid='$_SESSION[login_user1]';");
										$row=mysqli_fetch_assoc($result);
										
										echo "Staff ID : ".$row['staffid']; 
																
									}                                            
							?>
						</div>
						<div class="staffname">
							<?php
									if(isset($_SESSION['login_user1']))
									{
										$result=mysqli_query($connect,"SELECT * from staff WHERE staffid='$_SESSION[login_user1]';");
										$row=mysqli_fetch_assoc($result);
										echo "Staff Name : ".$row['staffname'];                         
									}                                            
							?>
						</div> 
						<form  action="" method="post">
							<div style="margin-top:50px;">
								<span style="width:49%; font-size:20px; " class="details">Entry Vehicle No</span>           
							</div>
							<div >				
								<input class="form-control" style="width:49%;" type="text" name="searchid" placeholder="Enter Vehicle Number....." required autocomplete="off">					
							</div>
							
							<br>
							<button style="width:15%; "  type="submit" name="search" class="btn btn-info">
							<span>Search</span>
							</button>
						</form>
						<div class="margi">
						</div>
						<div class="b">
						<?php

				if(isset($_POST['search']))
				{
					$search=mysqli_query($connect,"SELECT * FROM `overall` WHERE `vehicle_no`='$_POST[searchid]'");

					if(mysqli_num_rows($search)==0)
					{
						?>
							<script>
								alert("Vehicle Number or Status is Not Correct.");
							</script>
						<?php
						
					}
					else
					{
							echo "<div  class='scroll'>";
							echo "<table class ='table'>";
							echo "<tr style='background-color: lightgreen;'>";

							echo "<th>"; echo "Vehicle Number"; echo "</th>";
							echo "<th>"; echo "Vehicle Was"; echo "</th>";
							echo "<th>"; echo "Status"; echo "</th>";
							echo "<th>"; echo "All Process"; echo "</th>";
							echo "<th>"; echo "Exit"; echo "</th>";
							
							echo "</tr>";

						while($row=mysqli_fetch_assoc($search))
						{
								$_SESSION['vehicle3']=$row['vehicle_no'];
								echo "<tr style='background-color: white;'>";

								echo "<td>"; echo $row['vehicle_no']; echo "</td>";
								echo "<td>"; echo $row['vehicle_is']; echo "</td>";
								echo "<td>"; echo $row['status']; echo "</td>";
								echo "<td>"; echo "Done"; echo "</td>";
								echo "<td>"; echo $row['exit_allow']; echo "</td>";
								
								echo "</tr>";

						}	

						echo "</table>";
						echo "</div>";
						
						?>

						<form action="exit3php.php" method="post">
							<div class="btn">
								<div class="button">
									<input type="submit" id="submit1" name="exit3" value="Exit">
								</div>	
							</div>
						</form>	
										
						<?php
					}
				}

				?>
						</div>
						
					</div>
				</section>
			<?php
		}
		else
		{
			?>
				<script>
					window.location="../index.php";
				</script> 
			<?php
		}
	?>


</body>
</html>