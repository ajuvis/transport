<?php

    $connect=mysqli_connect("localhost","root","","transport");  /* server name, username, password , database name */
    
?>