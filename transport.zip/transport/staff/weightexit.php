<?php
    include "connection.php";
	  include "nav.php";

    if(isset($_POST['submitweightexit']))
		{
                            
                  $result2=mysqli_query($connect,"SELECT * from `overall` where vehicle_no='$_SESSION[vehicle_no]';");
                  $row=mysqli_fetch_assoc($result2);
                  if($row['vehicle_is']=='Empty')
                  {
                        $weightin=$row['weight_in'];
                        $weightout=$row['weight_out'];
                        $finalweight=$weightout-$weightin;
                        mysqli_query($connect,"UPDATE `overall` SET `status`='Weight Verified from Staff' , `weight`='$finalweight' WHERE vehicle_no='$_SESSION[vehicle_no]';");
                        ?>
                              <script>
                                          var stri="<?php echo $_SESSION['vehicle_no']; ?>";
                                          alert("Vehicle Number: "+stri);
                                          window.location="weightout.php";
                              </script>
                        <?php
                  }

                  if($row['vehicle_is']=='Full')
                  {
                        mysqli_query($connect,"UPDATE `overall` SET `status`='Weight Verified from Staff' WHERE vehicle_no='$_SESSION[vehicle_no]';");
                        ?>
                              <script>
                                          var stri="<?php echo $_SESSION['vehicle_no']; ?>";
                                          alert("Vehicle Number: "+stri);
                                          window.location="weightout.php";
                              </script>
                        <?php
                  }
		}
    if(isset($_POST['submitweightpending']))
		{
                  $result2=mysqli_query($connect,"SELECT * from `overall` where vehicle_no='$_SESSION[vehicle_no]';");
                  $row=mysqli_fetch_assoc($result2);
                  if($row['vehicle_is']=='Empty')
                  {
                        $weightin=$row['weight_in'];
                        $weightout=$row['weight_out'];
                        $finalweight=$weightout-$weightin;
                        mysqli_query($connect,"UPDATE `overall` SET `status`='Weight Verification is Pending' , `weight`='$finalweight' WHERE vehicle_no='$_SESSION[vehicle_no]';");
                        ?>
                              <script>
                                          var stri="<?php echo $_SESSION['vehicle_no']; ?>";
                                          alert("Vehicle Number: "+stri);
                                          window.location="weightout.php";
                              </script>
                        <?php
                  }
                  
                  if($row['vehicle_is']=='Full')
                  {
                        mysqli_query($connect,"UPDATE `overall` SET `status`='Weight Verification is Pending' WHERE vehicle_no='$_SESSION[vehicle_no]';");
                        ?>
                              <script>
                                          var stri="<?php echo $_SESSION['vehicle_no']; ?>";
                                          alert("Vehicle Number: "+stri);
                                          window.location="weightout.php";
                              </script>
                        <?php
                  }
		}

?>