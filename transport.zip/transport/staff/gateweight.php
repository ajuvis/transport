<?php
	include "connection.php";
	include "nav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gate</title> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<style>
        body{
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            
        }
        .container{	
            margin-left:auto;
            margin-right:auto;
            margin-top:150px;
            width:500px;
        }


        .container .box{
            width: 100%;
            height: 320px;
            background: white;
            text-align:center;
            border-radius:3px;
            font-family:'Times New Roman', Times, serif;
        }

        .container .box:hover{			
            background: lightgreen;
            font-family: Arial, Helvetica, sans-serif;
            font-style: italic;
        }

        .container .box h1{
            padding: 20px;
            text-decoration: underline;
        }

        .container .box .select input{
            display:  block;
            margin: auto;
            margin-top: 40px;
            width: 80%;
            height : 50px;
            cursor:pointer;
            border-radius:5px;
            border: 1px solid blue;
            font-size: 20px;
        }
        .container .box .select input:hover{
            font-size: 25px;
            font-weight: 600;
            color: darkgreen;
            background: lightgrey;
            height : 55px;
            width: 85%;
        }
    </style>
</head>
<body>
		<?php
			if(isset($_SESSION['login_user2']))
			{
				?>
					<div class="container">
						<form action="" method="post">
							<div class="box">
								<h1>Weight Verification</h1>	
                                    <div class="select">
                                        <input type="submit" name="weightin" value="Weighting at Entry">
                                        <input type="submit" name="weightout" value="Weighting before Exit">
                                    </div>
							</div>
						</form>
					</div>
				<?php
			}
			else{
				?>
					<script>
						window.location="../index.php";
					</script> 
				<?php
			}
		?>	
	<?php 
	
		if(isset($_POST['weightin'])){
			?>
			<script type="text/javascript">
				window.location="weightin.php"; 
			</script>
			<?php
		}
		if(isset($_POST['weightout'])){
			?>
			<script type="text/javascript">
				window.location="weightout.php"; 
			</script>
			<?php
		}
	?>
</body>
</html>