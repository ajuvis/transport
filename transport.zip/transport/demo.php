<?php
	include "../connection/connection.php";
	include "nav.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Head</title>
   <meta http-equiv="refresh" content="15">
   <script src="https://kit.fontawesome.com/a076d05399.js"></script>
   <link rel="stylesheet" href="../css/head/dashboard.css">
</head>
<body>

   <?php
        if(isset($_SESSION['login_user']))
        {
            ?>
               <div class="center">   
                  <div class="container">
                  <div style="color:Purple; font-family:cursive; font-wieght:bold; margin-bottom:20px; font-size:20px; text-align:center;">
                           <?php
                           
                                 if(isset($_SESSION['login_user']))
                                 {
                                       $result=mysqli_query($connect,"SELECT * from head WHERE headID='$_SESSION[login_user]';");
                                       $row=mysqli_fetch_assoc($result);
                                    
                                       echo "Welcome : ".$row['Full_Name'];                          
                                 }    
                                 $count=0;
                                 $count1=0;
                                 $count2=0;
                                 $count3=0;
                                 $count4=0;
                                 $count5=0;
                               /*   $result1=mysqli_query($connect,"SELECT * from `vehiclefull` WHERE `status`='Pending';");
                                 $count=mysqli_num_rows($result1);
                                 $result2=mysqli_query($connect,"SELECT * from `overall` WHERE (`status`='Weight Verified from Staff' || `status`='Weight Verification is Pending') && `vehicle_is`='Full';");
                                 $count1=mysqli_num_rows($result2);
                                 $result3=mysqli_query($connect,"SELECT * from `final` WHERE `vehicle_is`='Full';");
                                 $count2=mysqli_num_rows($result3);
                                 $result4=mysqli_query($connect,"SELECT * from `vehicleempty` WHERE `status`='Pending';");
                                 $count3=mysqli_num_rows($result4);
                                 $result5=mysqli_query($connect,"SELECT * from `overall` WHERE (`status`='Weight Verified from Staff' || `status`='Weight Verification is Pending') && `vehicle_is`='Empty';");
                                 $count4=mysqli_num_rows($result5);
                                 $result6=mysqli_query($connect,"SELECT * from `final` WHERE `vehicle_is`='Empty'");
                                 $count5=mysqli_num_rows($result6); */
                           ?>
                     </div>

                        <div class="btn1">
                           
                           <div class="noti">
                              <?php
                                 echo $count;
                              ?>
                           </div>
                           <a href="verifyfull.php"><input type="submit" value="Verify Vehicle (FULL)"></a> 
                           
                        </div>
                        
                        <div class="btn1">
                           <div class="noti">
                              <?php
                                 echo $count1;
                              ?>
                           </div>
                           <a href="exitfull.php"><input type="submit" value="Exit Allow (FULL)"></a> 
                        </div>

                        <div class="btn1">
                           <div class="noti">
                              <?php
                                 echo $count2;
                              ?>
                           </div>
                           <a href="detailfull.php"><input type="submit" value="Details (FULL)"></a> 
                        </div>

                        <div class="btn2">
                           <div class="noti">

                              <?php
                                 echo $count3;
                              ?>
                           </div>
                           <a href="verifyempty.php"><input type="submit" value="Verify Vehicle (EMPTY)"></a> 
                           
                        </div>
                        
                        <div class="btn2">
                           <div class="noti">
                              <?php
                                 echo $count4;
                              ?>
                           </div>
                           <a href="exitempty.php"><input type="submit" value="Exit Allow (EMPTY)"></a> 
                        </div>

                        <div class="btn2">
                           <div class="noti">
                              <?php
                                 echo $count5;
                              ?>
                           </div>
                           <a href="detailempty.php"><input type="submit" value="Details (EMPTY)"></a> 
                        </div>
                        
                        <div class="btn">
                           <a href="staff_details.php"><input type="submit" value="Staff Details"></a> 
                        </div>
                        <div class="btn">
                           <a href="staff_add.php"><input type="submit" value="Staff Add"></a> 
                        </div>
                        <div class="btn">
                           <a href="staff_delete.php"><input type="submit" value="Staff Modification"></a> 
                        </div>
                  </div>
               </div>
            <?php
        }
        else
        { 
			?>
                <script>
                    window.location="../index.php";
                </script> 
            <?php
        }
    ?>     	
</body>
</html>