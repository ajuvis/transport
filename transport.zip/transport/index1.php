<?php
	include "nav.php";
?>

<?php
	if(isset($_POST['submit']))
		{
			$count=0;

			if('admin'===$_POST['user'])
			{

				$pre_stmt = $connect->prepare("SELECT * from admin WHERE adminID = ? && u_password = ? ");
				$pre_stmt->bind_param("ss",$_POST["userID"],$_POST["password"]);
				$pre_stmt->execute();
				$result = $pre_stmt->get_result();
				if($result->num_rows > 0){
					$row = $result->fetch_assoc();
					$_SESSION['login'] = $_POST['userID'];
					header('location: admin/admin.php'); 
				}
				else{
					?>           
						<script type="text/javascript">
						alert("The Username and Password doesn't match.");
                        window.location="index.php"; 
						</script>      
					<?php
				}
/* 
				$result=mysqli_query($connect,"SELECT * from admin WHERE adminID='$_POST[userID]' && u_password='$_POST[password]';");
				$row=mysqli_fetch_assoc($result);
				$count=mysqli_num_rows($result);
				
				if($count==0)
				{
					?>           
						<script type="text/javascript">
						alert("The Username and Password doesn't match.");
                        window.location="index.php"; 
						</script>      
					<?php
				}
				else{
					$_SESSION['login'] = $_POST['userID']; 
					?>
						<script type="text/javascript">
						window.location="admin/admin.php"; 
						</script>
					<?php
				} */
			}
			if('head'==$_POST['user'])
			{
				$password=$_POST['password'];
				$pre_stmt = $connect->prepare("SELECT * from head WHERE headID = ?");
				$pre_stmt->bind_param("s",$_POST["userID"]);
				$pre_stmt->execute();		
				$result = $pre_stmt->get_result();
				
				if($result->num_rows > 0){
					$row = $result->fetch_assoc();
					if(password_verify($password,$row['h_password'])){
						$_SESSION['login_user'] = $_POST['userID'];
						header('location: head/dashboard.php'); 
					}
					else{
						?>           
						<script type="text/javascript">
						alert("The Password doesn't match.");
                        window.location="index.php"; 
						</script>      
					<?php
					} 
				}
				else{
					?>           
						<script type="text/javascript">
						alert("The Username doesn't exist.");
                        window.location="index.php"; 
						</script>      
					<?php
				} 

				/* 	$password=$_POST['password'];
				$result=mysqli_query($connect,"SELECT * from head WHERE headID='$_POST[userID]';");
				
				$row=mysqli_fetch_assoc($result);
				
				if(password_verify($password,$row['u_password'])){
						$count=mysqli_num_rows($result);
				}
				
				if($count==0)
				{
					?>           
						<script type="text/javascript">
						alert("The Username and Password doesn't match.");
                        window.location="index.php";
						</script>      
					<?php
				}
				else{
					$_SESSION['login_user'] = $_POST['userID']; 
				 	?>
						<script type="text/javascript">
						window.location="head/head.php"; 
						</script>
					<?php
				}*/
			}
			if('entrystaff'==$_POST['user'])
			{
				$password=$_POST['password'];
				$place="Gate Entry";
				$pre_stmt = $connect->prepare("SELECT * from staff_details WHERE s_username = ? && location = ?");
				$pre_stmt->bind_param("ss",$_POST["userID"],$place);
				$pre_stmt->execute();		
				$result = $pre_stmt->get_result();
				
				if($result->num_rows > 0){
					$row = $result->fetch_assoc();
					if(password_verify($password,$row['s_password'])){
						$_SESSION['gate'] = $_POST['userID'];
						header('location: staff/gate/gate.php'); 
					}
					else{
						?>           
						<script type="text/javascript">
						alert("The Password doesn't match.");
                        window.location="index.php"; 
						</script>      
					<?php
					} 
				}
				else{
					 ?>           
						<script type="text/javascript">
						alert("The Username doesn't exist.");
                        window.location="index.php"; 
						</script>      
					<?php 
				} 

			/* 	$password=$_POST['password'];
				$result=mysqli_query($connect,"SELECT * from staff WHERE staffid='$_POST[userID]' && place='Entry_Gate';");
				
				$row=mysqli_fetch_assoc($result);
				if($row>0)
				{
					if(password_verify($password,$row['u_password'])){
						$count=mysqli_num_rows($result);
					}
				}
				
				
				if($count==0)
				{
					?>           
						<script type="text/javascript">
						alert("The Username and Password doesn't match.");
                        window.location="index.php";
						</script>      
					<?php
				}
				else{
					$_SESSION['login_user1'] = $_POST['userID']; 
					?>
						<script type="text/javascript">
						window.location="staff/gate.php"; 
						</script>
					<?php
				} */


			}
			if('weightstaff'==$_POST['user'])
			{

				$password=$_POST['password'];
				$place="Weighting Place";
				$pre_stmt = $connect->prepare("SELECT * from staff_details WHERE s_username = ? && location = ?");
				$pre_stmt->bind_param("ss",$_POST["userID"],$place);
				$pre_stmt->execute();		
				$result = $pre_stmt->get_result();

				if($result->num_rows > 0){
					/* 	$row = $result->fetch_assoc();
						if(password_verify($password,$row['s_password'])){
							$_SESSION['gate'] = $_POST['userID'];
							header('location: staff/gate.php'); 
						}
						else{
							?>           
							<script type="text/javascript">
							alert("The Password doesn't match.");
							window.location="index.php"; 
							</script>      
						<?php
						}  */
						echo "Successful";
					}
					else{
						/* ?>           
							<script type="text/javascript">
							alert("The Username doesn't exist.");
							window.location="index.php"; 
							</script>      
						<?php */
						echo "Unsuccessful";
					} 

				/* $password=$_POST['password'];
				$result=mysqli_query($connect,"SELECT * from staff WHERE staffid='$_POST[userID]' && place='Weighting_Palce';");
				
				$row=mysqli_fetch_assoc($result);
				
				if($row>0)
				{
					if(password_verify($password,$row['u_password'])){
						$count=mysqli_num_rows($result);
					}
				}
				
				
				if($count==0)
				{
					?>           
						<script type="text/javascript">
						alert("The Username and Password doesn't match.");
                        window.location="index.php";
						</script>      
					<?php
				}
				else{
					$_SESSION['login_user2'] = $_POST['userID']; 
					?>
						<script type="text/javascript">
						window.location="staff/gateweight.php"; 
						</script>
					<?php
				} */
			}
			
		}
	?>