<?php
	include "../connection/after_login_connection.php";

    switch($_POST['action']){
        case 'registeration':
            $pre_stmt = $connect->prepare("SELECT * from head WHERE headID = ?");
			$pre_stmt->bind_param("s",$_POST["headid"]);
			$pre_stmt->execute();
			$result = $pre_stmt->get_result();
			if($result->num_rows > 0){
                $pre_stmt->close();
                $connect->close();
				?>
                    <script>
                        alert("User already exist!");
                        window.location="admin.php";
                    </script>
                <?php
			}
            else{
                $headid=$_POST['headid'];
                $fullname=$_POST['fullname'];
                $password = password_hash($_POST['password'], PASSWORD_BCRYPT,['cost'=> 9] );

                $pre_stmtinsert = $connect->prepare("INSERT INTO head(headID,Full_Name,h_password) VALUES (?,?,?)");
                $pre_stmtinsert->bind_param("sss",$headid, $fullname,$password);
                $pre_stmtinsert->execute();
                if($pre_stmtinsert){
                    $pre_stmt->close();
                    $connect->close();
                    ?>
                        <script>
                            alert("Added Successfully!");
                            window.location="admin.php";
                        </script>
                    <?php
                } 
            }
            break;
        
        default:
            break;
    }

?>