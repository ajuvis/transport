<?php
	include "../connection/connection.php";
	include "nav.php";
    if(isset($_SESSION['login'])){
        ?>
            
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="../css/admin/admin.css">
</head>
<body>
        <form action="adminphp.php" method="POST">
            <input type="hidden" name="action" value="registeration">
            <table>
                <h1>Registeration for Head</h1>
                <tr>
                    <td>Head ID: </td>
                    <td><input type="text" name="headid" required autocomplete="off"></td>    
                </tr>
                <tr>
                    <td>Full Name: </td>
                    <td><input type="text" name="fullname" required autocomplete="off"></td>
                </tr>
                <tr>
                    <td>Password: </td>
                    <td><input type="password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least 1 number,1 uppercase, 1 lowercase letter, and at least 8 or more characters" required autocomplete="off"></td>
                </tr>
                <tr>
                    <td colspan="2" id="btn"><input type="submit" name="submit" value="Register"></td>
                </tr>
            </table>
        </form>
</body>
</html>
        <?php
    }
    else{
        ?>
						<script type="text/javascript">
						window.location="../index.php"; 
						</script>
					<?php
    }

?>


