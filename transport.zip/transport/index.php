<?php
	define('Active',false); 
	include "connection/connection.php";
	include "nav.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Login</title>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<link rel="stylesheet" href="css/main.css">
</head>

<body>
	<div class="center">
		<div class="mid_logo">
			<img src="images/logo.png" alt="" >			
		</div>

		<h1>Transport Management</h1>
		<?php
			if(isset($_SESSION['login'])){
				header("location:admin/admin.php");
			}
			if(isset($_SESSION['login_user'])){
				header("location:head/dashboard.php");
			}
			if(isset($_SESSION['login_user1'])){
				header("location:staff/gate.php");
			}
			if(isset($_SESSION['login_user2'])){
				header("location:staff/gateweight.php");
			}
		?>
		<form action="index1.php" name="login" method="post" autocomplete="off">
		
			<input type="hidden" name="action" value="logindetails">
			<div class="option">
				<label>User :</label>
				<select id="user" name="user" required>
					<option value="head">Head</option>
					<option value="entrystaff">Entry & Exit Management Staff</option>
					<option value="weightstaff">Weight Management Staff</option>
					<option value="admin">Admin</option>
				</select>
			</div>

			<div class="txt_field">
				<label>Username : </label>
				<input type="text" id="userID" name="userID" placeholder="Enter username" onclick="record()" required>
			</div>
			
			<div class="txt_field">
				<label>Password : </label>
				<input type="password" id="password" name="password" placeholder="Enter Password" required>
			</div>

			<input id="login" type="submit" name="submit" value="Login">

		</form>
	</div>			
</body>
</html>