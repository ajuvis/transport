<?php

    session_start();
    if(isset($_SESSION['login']))
    {
        unset($_SESSION['login']);
    }
    if(isset($_SESSION['login_user']))
    {
        unset($_SESSION['login_user']);
    }
    if(isset($_SESSION['login_user1']))
    {
        unset($_SESSION['login_user1']);
    }
    if(isset($_SESSION['login_user2']))
    {
        unset($_SESSION['login_user2']);
    }

    header("location:index.php");

?>