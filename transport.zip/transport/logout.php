<?php

    session_start();
    if(isset($_SESSION['login']))
    {
        unset($_SESSION['login']);
    }
    if(isset($_SESSION['login_user']))
    {
        unset($_SESSION['login_user']);
    }
    if(isset($_SESSION['gate']))
    {
        unset($_SESSION['gate']);
    }
    if(isset($_SESSION['login_user2']))
    {
        unset($_SESSION['login_user2']);
    }

    header("location:index.php");

?>